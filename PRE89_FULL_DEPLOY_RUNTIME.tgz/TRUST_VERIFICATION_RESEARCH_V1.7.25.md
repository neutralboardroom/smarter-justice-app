# Smarter Justice v1.7.25 Trust and Verification Research

Research date: July 22, 2026

## Evidence and adaptation
### Legal Services Corporation
Source: https://www.lsc.gov/techreport
- Modernize high-quality self-help tools
- Support responsible AI innovation
- Use adaptive evaluation and data-driven improvement
- Smarter Justice adaptation: Keep public tools narrow, transparent, measurable, and reversible.

### National Center for State Courts
Source: https://www.ncsc.org/resources-courts/how-talk-your-court-users-about-ai
- Legal AI use requires context-specific caution
- Court users should be guided to trusted resources
- Personally identifiable or confidential information should not be placed into unapproved AI tools
- Smarter Justice adaptation: Add an AI-assisted draft verification checklist without reviewing or transmitting draft text.

### Federal Trade Commission
Source: https://www.ftc.gov/news-events/news/press-releases/2026/06/ftc-data-show-people-reported-losing-3-point-5-billion-imposter-scams-2025
- Imposter scams were the most reported fraud category in 2025
- Bank and government impersonation produced major reported losses
- Scams arrive through multiple communication channels
- Smarter Justice adaptation: Add a sender-independent verification workflow that avoids supplied links, numbers, and payment channels.

### Administrative Office of the U.S. Courts
Source: https://www.uscourts.gov/court-programs/jury-service/juror-scams
- Fake court contacts threaten prosecution and seek sensitive data
- Federal courts direct users to independently contact the clerk
- Official court contact should not demand sensitive data by phone or email
- Smarter Justice adaptation: Include court-specific verification and preservation steps while never declaring a notice authentic or fake.

### American Bar Association
Source: https://www.americanbar.org/news/abanews/aba-news-archives/2024/07/aba-issues-first-ethics-guidance-ai-tools/
- Competence, confidentiality, communication, and reasonable fees apply to generative AI use
- Legal professionals must consider applicable ethical obligations
- Smarter Justice adaptation: Keep AI safeguards visible in public and owner workflows; do not market automated output as professional review.

### World Wide Web Consortium
Source: https://www.w3.org/TR/WCAG22/
- Keyboard focus must remain visible and unobscured
- Targets need adequate size or spacing
- Help and repeated-entry behavior should be predictable
- Smarter Justice adaptation: Use large controls, visible focus, direct labels, no dragging, and no repeated sensitive data entry.

## Implemented
- Device-only suspicious-message verification planner
- Device-only AI-assisted draft verification checklist
- Local text and JSON exports
- Protected owner research ledger
- Explicit no-authentication, no-advice, no-deadline, no-save, no-AI-transmission, no-lead, and no-routing boundaries

## Rejected shortcuts
- Automated authenticity verdicts
- Automatic URL or caller reputation lookups
- Risk scores that imply a message is real or fake
- Uploading notices or drafts before confidential-document gates pass
- Sending reports automatically to courts, law enforcement, firms, banks, insurers, or professionals
- Treating checklist completion as legal or filing approval

## Next research
- Real-user comprehension testing
- Screen-reader and 400-percent zoom acceptance
- Jurisdiction-specific court scam resources
- Safe optional reporting links without transmitting user entries
- Evidence-provenance organizer that preserves originals and separates annotations

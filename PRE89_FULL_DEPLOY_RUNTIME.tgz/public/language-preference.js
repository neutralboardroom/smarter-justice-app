(function(){
  'use strict';
  const KEY='smarterJusticePreferredLanguageV20';
  const DRAFT='smarterJusticeLanguageSwitchDraftV20';
  function fields(){return Array.from(document.querySelectorAll('input[name],select[name],textarea[name]')).filter(el=>!['password','file','hidden'].includes(String(el.type||'').toLowerCase()));}
  function saveDraft(){
    const values={};
    for(const el of fields()){
      if(el.type==='checkbox'||el.type==='radio'){values[el.name]={type:el.type,value:el.value,checked:el.checked};}
      else values[el.name]={type:el.type||el.tagName.toLowerCase(),value:el.value};
    }
    try{sessionStorage.setItem(DRAFT,JSON.stringify({at:Date.now(),values}));}catch{}
  }
  function restoreDraft(){
    let record=null;try{record=JSON.parse(sessionStorage.getItem(DRAFT)||'null');}catch{}
    if(!record||Date.now()-Number(record.at||0)>15*60*1000)return;
    for(const el of fields()){
      const saved=record.values?.[el.name];if(!saved)continue;
      if(saved.type==='checkbox'||saved.type==='radio'){if(String(el.value)===String(saved.value))el.checked=Boolean(saved.checked);}
      else if(!el.value)el.value=String(saved.value||'');
      el.dispatchEvent(new Event('input',{bubbles:true}));
    }
    try{sessionStorage.removeItem(DRAFT);}catch{}
  }
  document.querySelectorAll('[data-language-switch]').forEach(link=>link.addEventListener('click',()=>{
    saveDraft();
    try{localStorage.setItem(KEY,link.dataset.languageSwitch||'en');}catch{}
  }));
  restoreDraft();
})();

'use strict';
// SMARTER_JUSTICE_PRE60_PRACTICE_DIRECTORY_PROGRESSIVE_DISCLOSURE
document.addEventListener('DOMContentLoaded',()=>{
  const input=document.getElementById('practiceFilter');
  const cards=[...document.querySelectorAll('.practice-card')];
  const toggle=document.getElementById('practiceDirectoryToggle');
  const status=document.getElementById('practiceDirectoryStatus');
  let expanded=false;
  // SMARTER_JUSTICE_PRE61_MOBILE_DIRECTORY_LIMIT
  // SMARTER_JUSTICE_PRE63_DIRECTORY_LIMIT
  const initialLimit=()=>window.matchMedia('(max-width:620px)').matches?6:9;
  const render=()=>{
    const query=String(input?.value||'').trim().toLowerCase();
    const target=decodeURIComponent(String(location.hash||'').replace(/^#/,''));
    let matches=0;
    cards.forEach((card,index)=>{
      const match=!query||card.textContent.toLowerCase().includes(query);
      if(match)matches+=1;
      const visible=match&&(Boolean(query)||expanded||index<initialLimit()||card.id===target);
      card.hidden=!visible;
      card.classList.toggle('pre60-initial-hidden',!visible);
    });
    if(status)status.textContent=query?matches+' matching legal '+(matches===1?'area':'areas'):'Showing '+(expanded?cards.length:Math.min(initialLimit(),cards.length))+' of '+cards.length+' legal areas';
    if(toggle){
      toggle.hidden=Boolean(query);
      toggle.textContent=expanded?'Show popular areas only':'Show all '+cards.length+' legal areas';
    }
  };
  input?.addEventListener('input',render);
  window.matchMedia('(max-width:620px)').addEventListener?.('change',render);
  toggle?.addEventListener('click',()=>{expanded=!expanded;render();if(!expanded)document.querySelector('.pre60-all-practices')?.scrollIntoView({behavior:'smooth',block:'start'});});
  render();
});

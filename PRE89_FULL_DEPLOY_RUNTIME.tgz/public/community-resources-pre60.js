'use strict';
// SMARTER_JUSTICE_PRE60_COMMUNITY_PROGRESSIVE_DISCLOSURE
document.addEventListener('DOMContentLoaded',()=>{
  const input=document.getElementById('communityResourceFilter');
  const cards=[...document.querySelectorAll('.community-need-card')];
  const toggle=document.getElementById('communityResourceToggle');
  const status=document.getElementById('communityResourceStatus');
  let expanded=false;
  // SMARTER_JUSTICE_PRE61_MOBILE_COMMUNITY_LIMIT
  // SMARTER_JUSTICE_PRE63_COMMUNITY_LIMIT
  const initialLimit=()=>6;
  const render=()=>{
    const query=String(input?.value||'').trim().toLowerCase();
    let matches=0;
    cards.forEach((card,index)=>{
      const match=!query||card.textContent.toLowerCase().includes(query);
      if(match)matches+=1;
      const visible=match&&(Boolean(query)||expanded||index<initialLimit()||card.classList.contains('is-focused'));
      card.hidden=!visible;
      card.classList.toggle('pre60-initial-hidden',!visible);
    });
    if(status)status.textContent=query?matches+' matching '+(matches===1?'category':'categories'):'Showing '+(expanded?cards.length:Math.min(initialLimit(),cards.length))+' of '+cards.length+' categories';
    if(toggle){toggle.hidden=Boolean(query);toggle.textContent=expanded?'Show fewer categories':'Show all '+cards.length+' categories';}
  };
  input?.addEventListener('input',render);
  window.matchMedia('(max-width:620px)').addEventListener?.('change',render);
  toggle?.addEventListener('click',()=>{expanded=!expanded;render();});
  render();
});

'use strict';
(function(){
  function selectedLabels(form){
    return [...form.querySelectorAll('input[name="need"]:checked')].map(input=>{
      const label=input.closest('label');
      return label?label.textContent.trim():input.value;
    });
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const form=document.getElementById('communityPlanForm');
    const panel=document.getElementById('communityPlanResult');
    const list=document.getElementById('communityPlanList');
    const printButton=document.getElementById('communityPrint');
    const clearButton=document.getElementById('communityClear');
    const shareButtons=[...document.querySelectorAll('#communityShare,.community-share-button')];
    if(form&&panel&&list){
      form.addEventListener('submit',event=>{
        event.preventDefault();
        const labels=selectedLabels(form);
        list.replaceChildren();
        const values=labels.length?labels:[form.dataset.emptyMessage||'Call 211 or use the official resource links below to choose a starting point.'];
        for(const text of values){const li=document.createElement('li');li.textContent=text;list.appendChild(li);}
        panel.hidden=false;
        panel.scrollIntoView({behavior:'smooth',block:'nearest'});
      });
    }
    if(printButton)printButton.addEventListener('click',()=>window.print());
    if(clearButton)clearButton.addEventListener('click',()=>{if(form)form.reset();if(panel)panel.hidden=true;if(list)list.replaceChildren();});
    for(const shareButton of shareButtons)shareButton.addEventListener('click',async()=>{
      const data={title:document.title,text:shareButton.dataset.shareText||'Community Resource Aid',url:location.href};
      try{
        if(navigator.share){await navigator.share(data);return;}
        await navigator.clipboard.writeText(location.href);
        shareButton.textContent=shareButton.dataset.copiedText||'Link copied';
      }catch{}
    });
    const focus=new URLSearchParams(location.search).get('focus');
    if(focus){
      const matches=[...document.querySelectorAll('.community-need-card[data-focus]')].filter(card=>(card.dataset.focus||'').split(/\s+/).includes(focus));
      if(matches.length){
        for(const card of matches)card.classList.add('is-focused');
        const status=document.getElementById('communityFocusStatus');
        if(status){
          const es=document.documentElement.lang==='es';
          const labels={basic:es?'necesidades prácticas':'practical needs',safety:es?'seguridad y crisis':'safety and crisis',wellbeing:es?'salud, beneficios y bienestar':'health, benefits, and wellbeing',substance:es?'consumo de sustancias y recuperación':'substance use and recovery',trafficking:es?'trata y explotación':'trafficking and exploitation',legal:es?'ayuda legal':'legal help',helper:es?'ayudar a otra persona':'helping someone else'};
          status.hidden=false;
          status.innerHTML=`<strong>${es?'Ruta enfocada':'Focused path'}:</strong> ${labels[focus]||focus}. <a href="${location.pathname}#community-needs">${es?'Mostrar todos los recursos':'Show all resources'}</a>`;
        }
        setTimeout(()=>matches[0].scrollIntoView({behavior:'smooth',block:'center'}),80);
      }
    }

    fetch('/api/community-resource-aid',{headers:{accept:'application/json'}}).then(r=>r.ok?r.json():null).then(data=>{
      const status=document.querySelector('[data-community-resource-status]');
      if(status&&data?.validation?.ok){const es=document.documentElement.lang==='es';status.textContent=`${es?'Catálogo de recursos verificado':'Verified resource catalog'} · ${data.resource.verificationDate}`;}
    }).catch(()=>{});
  });
})();

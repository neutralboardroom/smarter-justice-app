# PRE68 Known Limits

- Qualified legal/ethics, privacy, accessibility, and human rendered review of the protected PRE64 compliance surfaces remains pending.
- The segmented inherited-suite diagnostic reports failures truthfully; diagnostic success means the runner completed and the receipt is valid, not that every inherited test passed.
- The restored professional-membership route is included in static exact-source renders, but static evidence is not live-route or production acceptance.
- Runtime dependency installation is skipped in local source-only qualification and remains mandatory in CI/Render required mode.
- GitHub workflow execution, Render changes, deployment, and production promotion are not performed.

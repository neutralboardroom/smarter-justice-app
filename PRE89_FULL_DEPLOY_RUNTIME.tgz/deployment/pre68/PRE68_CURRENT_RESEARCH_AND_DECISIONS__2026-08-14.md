# PRE68 Current Research and Decisions — August 14, 2026

## Primary engineering sources

| Source | Material finding | Decision | Smarter Justice application |
|---|---|---|---|
| Node.js `child_process` documentation — https://nodejs.org/api/child_process.html | Child processes support explicit timeouts and bounded output handling. | ADOPT | Each inherited test runs in its own bounded Node child process with a 12-second ceiling and capped output. |
| Node.js test-runner documentation — https://nodejs.org/api/test.html | Modern Node supports controlled test execution, concurrency, and sharding, but the inherited Smarter Justice suite is a set of independent executable scripts rather than `node:test` cases. | ADAPT | Preserve every legacy executable while adding a manifest-driven segment runner instead of rewriting 166 tests solely for framework conformity. |
| GitHub Actions matrix documentation — https://docs.github.com/en/actions/using-jobs/using-a-matrix-for-your-jobs | Matrix jobs can report independent partitions and `fail-fast: false` allows all partitions to complete. | ADOPT | The PRE68 workflow runs seven independent segments and does not hide later blockers after the first failure. |
| GitHub Actions workflow syntax — https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions | Job timeouts bound stalled automation. | ADOPT | Each segment job has an eight-minute ceiling and evidence upload runs with `if: always()`. |

## Public/professional market review

| Source | Material finding | Decision | Rationale |
|---|---|---|---|
| Nolo lawyer matching — https://www.nolo.com/lawyers | A user can begin from the problem and move toward an attorney path without first mastering legal taxonomy. | ADAPT | Keep Smarter Justice's problem-first public entry and test its meaning and route, not one headline. |
| Avvo — https://www.avvo.com/ | Public legal discovery combines issue search, professional profiles, and educational help. | ADAPT | Preserve distinct public-help and professional-discovery routes while avoiding implied endorsement or pay-to-verify behavior. |
| Clio client intake — https://www.clio.com/features/client-intake/ | Professional value grows when intake/status workflows are explicit and operationally visible. | DEFER | PRE68 improves test/reporting infrastructure only; it does not claim new live intake or firm-operating capabilities. |

## Rejected or deferred changes

- **ADOPT:** restore the complete professional-membership page from the exact authoritative PRE67 Product Source after the canonical runtime carrier was proven truncated; do not synthesize or rewrite replacement copy.
- **REJECT:** rewriting accepted homepage copy merely to satisfy a historical phrase assertion.
- **REJECT:** treating a diagnostic known-failure list as an acceptance allowlist.
- **DEFER:** changing the protected PRE64 compliance pages before qualified legal/ethics, privacy, and accessibility review.
- **DEFER:** GitHub execution, Render configuration changes, deployment, or production promotion without Roger's exact authorization.

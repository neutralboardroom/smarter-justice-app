# Smarter Justice PRE68 Builder Readme

PRE68 uses the deterministic canonical PRE67 runtime carrier and applies only the PRE68 semantic, restoration, and segmented-test overlay during ordinary builds. The complete historical reconstruction remains available as `npm run rebuild:full-history`.

## Default source qualification

```sh
SJ_RUNTIME_INSTALL_MODE=skip npm run rebuild:fast
npm run qualify:pre68
PRE68_EVIDENCE_DIR=/path/to/static-evidence npm run qualify:pre68
```

## Complete inherited-suite diagnosis

```sh
npm run test:segments:pre68:diagnostic
```

Diagnostic mode must never be represented as suite acceptance. Gate mode fails on any failed or timed-out test. The aggregate historical audit remains `npm test` / `npm run test:aggregate:audit` inside the canonical runtime.

## Rendered review

```sh
npm run render:static:pre68
```

The 18-render matrix includes the restored professional-membership route. Static evidence is not live-route, production, accessibility, legal/ethics, or privacy acceptance.

## Mandatory handoff

Deliver Product Source, Evidence & Receipts, and Builder & Continuation ZIPs together with exact basename, size, and SHA-256. Missing, duplicate-byte, corrupt, or substituted roles fail closed.

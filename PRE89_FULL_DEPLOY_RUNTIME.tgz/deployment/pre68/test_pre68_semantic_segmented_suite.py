
import hashlib,json,os,pathlib,re,unittest,zipfile
ROOT=pathlib.Path(os.environ.get('RUNTIME','.runtime/smarter-justice-v1.7.98')).resolve();SOURCE=pathlib.Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
class Pre68(unittest.TestCase):
 def test_release_and_protected(self):
  server=(ROOT/'server.js').read_text();self.assertIn("currentPlatformRelease:'v2.0.0-pre68'",server);self.assertIn("platformMarker:'SMARTER_JUSTICE_PRE68_SEMANTIC_SEGMENTED_ACCEPTANCE'",server)
  expected={'public/attorney-partner-tour.html':'eada21a990bddbc27e6bcfee271a23b7e387e4ec33711993494cacc6479a8449','public/professional-responsibility.html':'fa06a395f992e88817bce057066ac13adc93f816916818a1e242186ef786228c','public/styles.css':'a1c9426bef0101f487ceaba54bd7002751398db5ce889cc89e191d664aceb6ce'}
  for rel,want in expected.items():self.assertEqual(sha(ROOT/rel),want,rel)
 def test_segment_coverage_and_aggregate(self):
  m=json.loads((ROOT/'deployment/pre68/PRE68_TEST_SEGMENT_MANIFEST__2026-08-14.json').read_text());tests=[x for s in m['segments'] for x in s['tests']];self.assertEqual(len(m['segments']),7);self.assertEqual(len(tests),166);self.assertEqual(len(set(tests)),166)
  p=json.loads((ROOT/'package.json').read_text());aggregate=p['scripts']['test:aggregate:audit'];self.assertEqual(p['scripts']['test'],aggregate);self.assertEqual(len(re.findall(r'node\s+(tests/[^\s&]+\.js)',aggregate)),166);self.assertIn('run-pre68-segmented-suite.js',p['scripts']['test:segments:pre68'])
 def test_carrier_and_three_roles(self):
  m=json.loads((SOURCE/'deployment/pre68/PRE68_CARRIER_MANIFEST__2026-08-14.json').read_text());a=SOURCE/m['archive'];self.assertEqual(a.stat().st_size,m['archiveSizeBytes']);self.assertEqual(sha(a),m['archiveSha256']);
  with zipfile.ZipFile(a) as z:self.assertEqual(sum(not n.endswith('/') for n in z.namelist()),m['fileCount'])
  c=json.loads((ROOT/'deployment/pre68/SEMANTIC_SEGMENTED_RELEASE_CONTRACT__PRE68.json').read_text());self.assertEqual([x['role'] for x in c['requiredDeliverables']],['PRODUCT_SOURCE','EVIDENCE_RECEIPTS','BUILDER_CONTINUATION'])
 def test_semantic_patch_and_metadata(self):
  static=(ROOT/'tests/static-checks.test.js').read_text();self.assertIn('evaluateHomepage',static);self.assertNotIn('Start with the problem—not the legal category/.test(index)',static);membership=(ROOT/'public/professional-membership.html');text=membership.read_text();[self.assertIn(token,text) for token in ['<head','</head>','<body','<main','</main>','https://smarterjustice.com/professional-membership.html']];self.assertEqual(sha(membership),'0cc9b5b558328d11b234dfc9d0315df5c2a7da200f8a43341cf4ab89f08a249b')
 def test_source_scripts_and_workflow(self):
  p=json.loads((SOURCE/'package.json').read_text());self.assertIn('bootstrap-pre68-fast-carrier.js',p['scripts']['rebuild:fast']);self.assertIn('apply-pre68-semantic-segmented-suite.js',p['scripts']['rebuild:fast']);self.assertIn('bootstrap-sitewide-release.js',p['scripts']['rebuild:full-history']);self.assertIn('apply-pre68-semantic-segmented-suite.js',p['scripts']['rebuild:full-history'])
  w=(SOURCE/'.github/workflows/pre68-segmented-acceptance.yml').read_text();self.assertIn('fail-fast: false',w);self.assertIn('timeout-minutes: 8',w);self.assertIn('retention-days: 14',w)
if __name__=='__main__':unittest.main()

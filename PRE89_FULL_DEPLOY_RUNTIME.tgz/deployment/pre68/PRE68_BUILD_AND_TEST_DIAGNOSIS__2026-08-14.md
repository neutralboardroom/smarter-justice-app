# PRE68 Build and Test Diagnosis

PRE68 keeps the ordinary source-only rebuild on the hash-verified PRE67 canonical carrier and applies only the PRE68 overlay. The focused rebuild completed in 5.37 seconds. The historical 166-command test chain previously stopped at the first assertion and several tests could retain child processes long enough to obscure later results.

PRE68 adds a manifest-bound seven-segment runner. Each test executes in a separate detached process group with a 30-second per-test ceiling, forced process-tree termination, bounded captured output, a 240-second global ceiling, and an immutable JSON receipt. Diagnostic mode completed all 166 tests in 100.545 seconds: 146 passed, 20 failed, and none timed out. The 20 failures remain failures; their classification is explanatory only.

The rebuild also detected a concrete predecessor-carrier defect: `public/professional-membership.html` in the canonical PRE67 runtime carrier lacked `</head>`, `<body>`, and `<main>` openings. The exact PRE67 Product Source retained the complete accepted 18,438-byte page. PRE68 restores those exact source bytes and verifies the source hash on every focused rebuild.

The static Chromium matrix now covers nine routes across phone and desktop viewports. All 18 renders completed with zero automated findings. GitHub live-route CI, Render, and production were not executed.

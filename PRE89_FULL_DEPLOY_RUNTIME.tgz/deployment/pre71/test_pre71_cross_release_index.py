#!/usr/bin/env python3
import json, os, pathlib, subprocess, tempfile, shutil
RUNTIME=pathlib.Path(os.environ.get('RUNTIME','.runtime/smarter-justice-v1.7.98')).resolve()
INDEX=RUNTIME/'deployment/pre71/PRE71_CROSS_RELEASE_THREE_DELIVERABLE_INDEX__2026-08-15.json'
VERIFIER=RUNTIME/'scripts/verify-pre71-cross-release-index.js'
def run(root):
 p=subprocess.run(['node',str(VERIFIER),'--root',str(root)],text=True,capture_output=True,timeout=15)
 return p.returncode,json.loads(p.stdout)
code,out=run(RUNTIME); assert code==0 and out['ok'] and out['releaseCount']==6 and out['artifactCount']==18, out
cases=[]
def neg(label,mutate,fragment):
 with tempfile.TemporaryDirectory(prefix='sj-pre71-') as td:
  root=pathlib.Path(td); (root/'deployment/pre71').mkdir(parents=True); (root/'scripts').mkdir(); (root/'lib').mkdir()
  shutil.copy2(VERIFIER,root/'scripts/verify-pre71-cross-release-index.js'); shutil.copy2(RUNTIME/'lib/crossReleaseReceiptIndexPre71.js',root/'lib/crossReleaseReceiptIndexPre71.js')
  doc=json.loads(INDEX.read_text()); mutate(doc); (root/'deployment/pre71/PRE71_CROSS_RELEASE_THREE_DELIVERABLE_INDEX__2026-08-15.json').write_text(json.dumps(doc))
  c,o=run(root); assert c!=0 and any(fragment in e for e in o['errors']), (label,o); cases.append(label)
neg('missing-release',lambda d:d['releases'].pop(),'RELEASE_COUNT')
neg('missing-role',lambda d:d['releases'][0]['artifacts'].pop(),'ROLE_COUNT')
neg('duplicate-hash',lambda d:d['releases'][0]['artifacts'][1].update(sha256=d['releases'][0]['artifacts'][0]['sha256']),'DUPLICATE_ARTIFACT_HASH')
neg('wrong-role-order',lambda d:d['releases'][0]['artifacts'].reverse(),'ROLE_ORDER')
neg('chain-tamper',lambda d:d.update(crossReleaseSetSha256='0'*64),'CHAIN_DIGEST_MISMATCH')
print(json.dumps({'ok':True,'release':'v2.0.0-pre71','baseline':out,'negativeCases':cases},indent=2))

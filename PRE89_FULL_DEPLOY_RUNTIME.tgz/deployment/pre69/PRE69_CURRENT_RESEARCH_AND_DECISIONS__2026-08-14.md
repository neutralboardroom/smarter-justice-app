# PRE69 Current Research and Decisions

**Research date:** August 14, 2026  
**Scope:** public legal-help navigation, attorney-directory trust and profile models, professional intake/operations platforms, mobile/accessibility evaluation, and implications for PRE69's current-authority regression work.

This review informs original Smarter Justice work. It does not authorize copying, unsupported comparisons, public claims that a deferred feature is live, or changes made only for novelty.

## Source review and dispositions

| Source | Current material pattern observed | Decision | Smarter Justice rationale and PRE69 effect |
|---|---|---|---|
| Legal Services Corporation, “I Need Legal Help” — https://www.lsc.gov/about-lsc/what-legal-aid/i-need-legal-help | Location-based connection to LSC-funded civil legal-aid organizations, with LawHelp.org as a complementary information/forms source. | **ADAPT** | Preserve public routing by legal need and location, and keep official/nonprofit help clearly distinct from private-professional discovery. PRE69 changes regression authority only; it does not add an unqualified live eligibility or locator claim. |
| LawHelp.org, “About Us” and “Find Forms” — https://www.lawhelp.org/about-us and https://www.lawhelp.org/findforms | State-linked legal information, nonprofit referrals, self-help resources, multilingual form availability, and explicit instructions/limitations around generated documents. | **ADAPT / DEFER** | Continue source-linked public-help and preparation-tool semantics. Defer new court-form generation or filing integrations until jurisdiction, privacy, instruction-currentness, and authorization gates are qualified. No public feature is represented as newly live in PRE69. |
| LawHelp Hawai‘i Legal Services Portal — https://www.lawhelp.org/hi/portal | Guided resource/referral questions with an explicit statement that identifying information is not requested, plus matter-scope boundaries. | **ADOPT (principle)** | Privacy-minimized triage and explicit scope boundaries remain current authority for Smarter Justice. PRE69 keeps tests focused on stable route meaning and privacy boundaries rather than old implementation identifiers. |
| Justia Lawyer Directory and FAQ — https://www.justia.com/lawyers/ and https://lawyers.justia.com/faq | Search by legal issue and location; detailed, claimable profiles; legal-aid listings; multiple contact paths; and privacy-aware handling of profile email addresses. | **ADAPT** | Preserve issue/location discovery, claim/update paths, and separation between directory data, attorney-controlled information, and direct contact. Do not infer licensure, availability, endorsement, or ranking from mere directory presence. No PRE69 profile-data mutation. |
| FindLaw Lawyer Directory Help — https://lawyers.findlaw.com/lawyer/help/ | Search/browse by issue and location; explicit warning that absence from a directory does not establish licensure and that state authorities are the appropriate credential source. | **ADOPT (trust boundary)** | Keep identity, directory presence, credential status, specialty evidence, and portal acceptance separate. This supports PRE69's current-authority tests and the existing source/verification model without changing public copy. |
| Avvo — https://www.avvo.com/ | Attorney search, profiles, ratings, reviews, and public legal Q&A. | **ADAPT / REJECT FOR NOW** | Adapt transparent profile comparison and direct source links. Do not add proprietary-style ratings, unmoderated public Q&A, or outcome-implying ranking in PRE69 because verification, moderation, advertising/ethics, privacy, and appeal/correction requirements are not yet qualified. |
| Clio Grow / Clio feature pages — https://www.clio.com/features/online-intake-forms/ and https://www.clio.com/features/ | Structured intake, CRM, appointment booking, e-signature/document workflows, source tracking, client communications, and broader law-firm operations. | **DEFER / ADAPT ARCHITECTURALLY** | Maintain a clear boundary between public discovery/preparation and optional professional operations. Defer transactional integrations, matter transfer, scheduling, e-signature, and automated communications until authentication, consent, retention, provider, security, and deployment gates are qualified. |
| W3C WAI evaluation-tool guidance — https://www.w3.org/WAI/test-evaluate/tools/selecting/ | Automated tools can identify potential issues but cannot determine accessibility; human judgment is required. | **ADOPT** | PRE69 keeps automated browser findings separate from human visual review and does not claim WCAG conformance. Protected PRE64 surfaces remain review-pending. |
| W3C Mobile Accessibility — https://www.w3.org/WAI/standards-guidelines/mobile/ | Existing W3C accessibility standards apply to mobile experiences; mobile review must consider phones and other device contexts. | **ADOPT** | Preserve phone and desktop rendered evidence for representative public and professional routes. PRE69 records a reasoned no-interface-change decision because the evidence showed no material regression that justified altering protected or accepted pages. |

## Version decision

The highest-value evidence-backed PRE69 change is **test and release-governance modernization**, not a new public feature. Fourteen stale inherited assertions were replaced with named current semantic or exact-authority checks. Six protected/provider conflicts remain failures. Public pages, profiles, directory data, payment boundaries, provider configuration, and deployment state were not changed.

## Future roadmap implications

- Continue improving official-source referrals and source-currentness without implying eligibility, representation, or filing completion.
- Keep attorney-directory presence separate from credential verification and portal acceptance.
- Build professional intake/operations integrations only behind explicit consent, authentication, data-minimization, retention, provider, and deployment controls.
- Require combined automated and knowledgeable human accessibility review before any conformance claim.

# Next Version Improvement List — Smarter Justice PRE70

1. Complete qualified legal/ethics, privacy, accessibility, metadata, and knowledgeable human review of the protected PRE64 surfaces before changing their bytes or resolving their four related inherited failures.
2. Reconcile the two provider-topology/environment assertions with an explicitly approved production AI architecture; preserve fail-closed provider selection, secret isolation, auditability, and no-fallback-overclaim boundaries.
3. Add a receipt-schema regression test that independently verifies seven child segment receipts, exact 166-test coverage, manifest order, bounded termination, and zero failure relabeling.
4. Execute pinned exact-commit live-route CI only after an authorized branch/commit exists; keep its evidence distinct from static exact-source and post-deployment evidence.
5. Perform post-deployment route, interaction, screenshot, monitoring, and rollback checks only after explicit product-scoped deployment authorization.
6. Continue official-source and competitor research; prioritize source-currentness, credential separation, professional profile value, and privacy-minimized public-help routing over novelty.
7. Preserve the exact three-deliverable contract, deterministic double packaging, two untouched fresh-extraction cycles, and negative missing-role/duplicate-byte/corrupt-ZIP verification.

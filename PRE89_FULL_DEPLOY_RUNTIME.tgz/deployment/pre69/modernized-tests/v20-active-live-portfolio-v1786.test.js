'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const os=require('os');
const http=require('http');
const root=path.join(__dirname,'..');
process.env.NODE_ENV='test';
process.env.SMARTER_JUSTICE_STORAGE_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'sj-v20-v1786-'));
process.env.OWNER_CONTROL_CENTER_TOKEN='owner-v20-v1786-token-123456789';
const governance=require('../lib/v20LaunchGovernance');
const store=require('../lib/store');
const server=require('../server');
function request(base,pathname,headers={}){return new Promise((resolve,reject)=>{const req=http.request(new URL(pathname,base),{headers},res=>{const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>{const text=Buffer.concat(chunks).toString('utf8');let data=null;try{data=JSON.parse(text);}catch{}resolve({status:res.statusCode,data,text});});});req.on('error',reject);req.end();});}
(async()=>{
 const pkg=require('../package.json');const lock=require('../package-lock.json');const manifest=require('../portal-manifest.json');
 assert.equal(pkg.version,'1.7.98');assert.equal(lock.version,'1.7.98');assert.equal(lock.packages[''].version,'1.7.98');
 assert.equal(pkg.scripts.test.split(' && ').length,166);assert.equal(manifest.currentDevelopmentVersion,'1.7.98');assert.equal(manifest.latestZipName,'smarter-justice-v1.7.97-v34-community-network-aligned.zip');assert.equal(manifest.dependencyIndependentTestParts,166);assert.equal(manifest.testSuiteParts,167);
 const v=governance.validate();assert.equal(v.ok,true,v.errors.join('\n'));assert.equal(v.releaseVersion,'1.7.86');assert.equal(v.productionAccepted,false);assert.equal(v.deploymentPerformed,false);
 const home=fs.readFileSync(path.join(root,'public/index.html'),'utf8');const es=fs.readFileSync(path.join(root,'public/es/index.html'),'utf8');const language=fs.readFileSync(path.join(root,'public/language-preference.js'),'utf8');
 const currentAuthorityPre69=require('../lib/currentAuthorityRegressionPre69');const languageEntryPre69=currentAuthorityPre69.evaluateLanguageEntry({homepage:home,spanishHtml:es,languageScript:language});assert(languageEntryPre69.ok,`current English/Spanish entry semantics failed: ${languageEntryPre69.failures.join('; ')}`);
 const h1=(home.match(/<h1[^>]*>(.*?)<\/h1>/s)||[])[1].replace(/<[^>]+>/g,' ').trim();assert(h1.split(/\s+/).length<=14);
 assert(es.includes('<html lang="es">'));assert(es.includes('data-language-switch="en"'));assert(es.includes('storyRouteFormEs'));assert(es.includes('/es/inicio.js'));assert(es.includes('No se guarda ni se envía'));
 assert(language.includes('sessionStorage'));assert(language.includes('localStorage'));assert(language.includes("['password','file','hidden']"));
 for(const f of ['SPANISH_LIVE_ACCEPTANCE_V1.7.86.json','PAYMENT_READINESS_ACCEPTANCE_V1.7.86.json','AI_TOOLS_READINESS_ACCEPTANCE_V1.7.86.json','DATA_CONTINUITY_ACCEPTANCE_V1.7.86.json','LIVE_CAPABILITY_ACCEPTANCE_V1.7.86.json']){const d=require(path.join(root,f));assert.equal(d.accepted??d.productionReady,false,f);}
 const q=fs.readFileSync(path.join(root,'.github/workflows/production-qualification.yml'),'utf8');const st=fs.readFileSync(path.join(root,'.github/workflows/protected-staging-promotion.yml'),'utf8');const pr=fs.readFileSync(path.join(root,'.github/workflows/protected-production-promotion.yml'),'utf8');
 assert(q.includes("require('./package.json').version"));assert(!q.includes('RELEASE_EVIDENCE_V1.7.85.json'));assert(!st.includes('EXPECTED_VERSION: 1.7.85'));assert(!pr.includes('EXPECTED_VERSION: 1.7.85'));assert(st.includes("require('./package.json').version"));assert(pr.includes("require('./package.json').version"));
 await store.init();await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=`http://127.0.0.1:${server.address().port}`;
 try{const spanish=await request(base,'/es/');assert.equal(spanish.status,200);assert(spanish.text.includes('Orientación legal inicial'));assert.equal((await request(base,'/api/owner/v20-launch-governance')).status,403);const h={'x-owner-control-token':process.env.OWNER_CONTROL_CENTER_TOKEN};const allowed=await request(base,'/api/owner/v20-launch-governance',h);assert.equal(allowed.status,200);assert.equal(allowed.data.appVersion,'1.7.98');assert.equal(allowed.data.v20LaunchGovernance.validation.ok,true);const cc=await request(base,'/api/owner/control-center',h);assert.equal(cc.status,200);assert.equal(cc.data.version,'1.7.98');assert.equal(cc.data.v20LaunchGovernance.validation.ok,true);}finally{await new Promise(r=>server.close(r));}
 console.log('v20-active-live-portfolio-v1786.test.js passed');
})().catch(err=>{console.error(err);try{server.close(()=>{});}catch{}process.exit(1);});

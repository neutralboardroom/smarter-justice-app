# Smarter Justice PRE69 Builder Readme

PRE69 is a review-ready candidate built from the exact PRE68 three-artifact handoff. Ordinary source reconstruction uses the hash-verified PRE68 canonical runtime carrier and applies only the PRE69 overlay. The complete historical replay remains available as `npm run rebuild:full-history`.

Focused source qualification:

```bash
SJ_RUNTIME_INSTALL_MODE=skip npm run rebuild:fast
npm run qualify:pre69
```

Complete diagnostic, which records failures without claiming acceptance:

```bash
npm run diagnose:segments:pre69
```

Static exact-source browser evidence:

```bash
PRE69_BROWSER_EXECUTABLE=/usr/bin/chromium npm run render:static:pre69
```

Deployment qualification must use locked dependency installation and authorized exact-commit/live-route gates. Static evidence is not production evidence. All three PRE69 deliverables are mandatory together.

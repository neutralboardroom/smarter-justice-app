import hashlib,json,os,pathlib,re,unittest,zipfile
ROOT=pathlib.Path(os.environ.get("RUNTIME",".runtime/smarter-justice-v1.7.98")).resolve();SOURCE=pathlib.Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
class Pre69(unittest.TestCase):
 def test_release_and_protected(self):
  server=(ROOT/"server.js").read_text();self.assertIn("currentPlatformRelease:'v2.0.0-pre69'",server);self.assertIn("platformMarker:'SMARTER_JUSTICE_PRE69_CURRENT_AUTHORITY_REGRESSION'",server)
  expected={'public/attorney-partner-tour.html': 'eada21a990bddbc27e6bcfee271a23b7e387e4ec33711993494cacc6479a8449', 'public/professional-responsibility.html': 'fa06a395f992e88817bce057066ac13adc93f816916818a1e242186ef786228c', 'public/styles.css': 'a1c9426bef0101f487ceaba54bd7002751398db5ce889cc89e191d664aceb6ce', 'public/professional-membership.html': '0cc9b5b558328d11b234dfc9d0315df5c2a7da200f8a43341cf4ab89f08a249b'}
  for rel,want in expected.items():self.assertEqual(sha(ROOT/rel),want,rel)
 def test_segments_and_modernization(self):
  m=json.loads((ROOT/"deployment/pre69/PRE69_TEST_SEGMENT_MANIFEST__2026-08-14.json").read_text());tests=[x for s in m["segments"] for x in s["tests"]];self.assertEqual(len(m["segments"]),7);self.assertEqual(len(tests),166);self.assertEqual(len(set(tests)),166)
  c=json.loads((ROOT/"deployment/pre69/CURRENT_AUTHORITY_REGRESSION_CONTRACT__PRE69.json").read_text());self.assertEqual(len(c["modernizedTests"]),14);self.assertEqual(len(c["unresolvedInheritedFailures"]),6);self.assertFalse(c["knownFailuresTreatedAsPass"]);self.assertFalse(c["releaseAcceptanceClaimed"])
  for item in c["modernizedTests"]:self.assertEqual(sha(ROOT/item["test"]),item["pre69Sha256"],item["test"])
 def test_carrier_and_three_roles(self):
  m=json.loads((SOURCE/"deployment/pre69/PRE69_CARRIER_MANIFEST__2026-08-14.json").read_text());a=SOURCE/m["archive"];self.assertEqual(a.stat().st_size,m["archiveSizeBytes"]);self.assertEqual(sha(a),m["archiveSha256"]);
  with zipfile.ZipFile(a) as z:self.assertEqual(sum(not i.is_dir() for i in z.infolist()),m["fileCount"])
  c=json.loads((ROOT/"deployment/pre69/CURRENT_AUTHORITY_RELEASE_CONTRACT__PRE69.json").read_text());self.assertEqual([x["role"] for x in c["requiredDeliverables"]],["PRODUCT_SOURCE","EVIDENCE_RECEIPTS","BUILDER_CONTINUATION"])
 def test_source_build_commands(self):
  p=json.loads((SOURCE/"package.json").read_text());self.assertIn("bootstrap-pre69-fast-carrier.js",p["scripts"]["rebuild:fast"]);self.assertIn("apply-pre69-current-authority-regression.js",p["scripts"]["rebuild:fast"]);self.assertIn("bootstrap-sitewide-release.js",p["scripts"]["rebuild:full-history"]);self.assertIn("apply-pre69-current-authority-regression.js",p["scripts"]["rebuild:full-history"])
if __name__=="__main__":unittest.main()

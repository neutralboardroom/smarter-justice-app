# Smarter Justice protected deployment workflow — v1.7.85

This release does not deploy itself and does not authorize production traffic.

1. Bind the exact source ZIP and V14 packet identities.
2. Import the exact source tree into a dedicated Git branch.
3. Run clean-install qualification, the complete acceptance suite, SBOM generation, secret scanning, migration validation, and deterministic packaging in CI.
4. Promote the exact commit to the protected `staging` GitHub environment.
5. Use separate staging PostgreSQL, object storage, Stripe test mode, OpenAI project, email credentials, and domain.
6. Verify private upload, delete, checksum, object-key privacy, distributed rate limits, migrations, payment webhooks, AI kill switches, account journeys, accessibility, mobile behavior, and rollback.
7. Record live evidence. Set `OBJECT_STORAGE_LIVE_VERIFIED=true` only after the staging evidence is accepted.
8. Require Roger's protected `production` environment approval.
9. Promote the same exact commit. Do not rebuild different source during promotion.
10. Run post-deployment health and user-journey checks, then issue a detached deployment receipt.
11. Keep one web instance until mutable account and session state is coherently shared or normalized.
12. Roll back to the recorded last-known-good commit if any production gate fails.

ZIP files remain immutable release, recovery, and handoff evidence. They are not uploaded directly to the live service.

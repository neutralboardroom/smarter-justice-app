# PRE66 Next Version Improvement List

1. Consume a qualified PRE64 legal/ethics, privacy, and accessibility review receipt when available; otherwise preserve protected surfaces unchanged.
2. Run the manual full historical audit in GitHub Actions and bind its exact commit and logs to the next promotion candidate.
3. Add a browser image with known-good headless dependencies to CI so rendered accessibility and responsive screenshots can be accepted rather than merely capability-probed.
4. Split the inherited runtime test suite into independently cached segments while retaining one aggregate full-suite gate.
5. Promote the canonical carrier manifest to signed provenance when an owner-approved signing key and storage workflow are available.

import hashlib, json, os, pathlib, unittest, zipfile
ROOT=pathlib.Path(os.environ.get('RUNTIME','.runtime/smarter-justice-v1.7.98')).resolve()
SOURCE=pathlib.Path(__file__).resolve().parents[2]
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
class Pre66FastVerifiedCarrier(unittest.TestCase):
    def test_release_and_protected_surfaces(self):
        server=(ROOT/'server.js').read_text()
        self.assertIn("currentPlatformRelease:'v2.0.0-pre66'",server)
        self.assertIn("platformMarker:'SMARTER_JUSTICE_PRE66_FAST_VERIFIED_CARRIER'",server)
        expected={'public/attorney-partner-tour.html':'eada21a990bddbc27e6bcfee271a23b7e387e4ec33711993494cacc6479a8449','public/professional-responsibility.html':'fa06a395f992e88817bce057066ac13adc93f816916818a1e242186ef786228c','public/styles.css':'a1c9426bef0101f487ceaba54bd7002751398db5ce889cc89e191d664aceb6ce'}
        for rel,want in expected.items(): self.assertEqual(sha(ROOT/rel),want,rel)
        self.assertIn('qualified legal/ethics, privacy, and accessibility review',(ROOT/'public/professional-responsibility.html').read_text())
    def test_fast_default_and_full_history_audit(self):
        p=json.loads((SOURCE/'package.json').read_text()); scripts=p['scripts']
        self.assertIn('bootstrap-pre66-fast-carrier.js',scripts['postinstall'])
        self.assertNotIn('bootstrap-sitewide-release.js',scripts['postinstall'])
        self.assertIn('bootstrap-sitewide-release.js',scripts['rebuild:full-history'])
        self.assertIn('apply-pre65-three-deliverable-contract.js',scripts['rebuild:full-history'])
    def test_carrier_binding_and_three_deliverables(self):
        m=json.loads((SOURCE/'deployment/pre66/PRE66_CARRIER_MANIFEST__2026-08-14.json').read_text()); a=SOURCE/m['archive']
        self.assertEqual(a.stat().st_size,m['archiveSizeBytes']); self.assertEqual(sha(a),m['archiveSha256'])
        with zipfile.ZipFile(a) as z: self.assertEqual(len([n for n in z.namelist() if not n.endswith('/')]),m['fileCount'])
        c=json.loads((ROOT/'deployment/pre66/FAST_VERIFIED_BUILD_CONTRACT__PRE66.json').read_text())
        self.assertEqual([x['role'] for x in c['requiredDeliverables']],['PRODUCT_SOURCE','EVIDENCE_RECEIPTS','BUILDER_CONTINUATION'])
        self.assertEqual(c['releaseGate']['missingAnyDeliverable'],'FAIL')
    def test_inherited_static_trust_blockers_repaired(self):
        for name in ['business-law.html','real-estate.html','personal-injury.html','medical-malpractice.html','index.html']:
            html=(ROOT/'public'/name).read_text().lower()
            self.assertTrue('not a law firm' in html or 'private support service' in html,name)
if __name__=='__main__': unittest.main()

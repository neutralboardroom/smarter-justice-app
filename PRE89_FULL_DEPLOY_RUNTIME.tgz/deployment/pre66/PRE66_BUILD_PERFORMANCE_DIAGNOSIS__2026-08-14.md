# PRE66 Build Performance Diagnosis

## Measured PRE65 behavior

- The inherited runtime suite consumed about 30 seconds before current overlays.
- The root lifecycle replay contained 111 serial commands and reapplied the PRE22-PRE65 history on every ordinary build.
- A nested `npm ci` could wait indefinitely in a network-restricted workspace.
- Chromium visual probing waited about 25 seconds before an environment timeout.
- The monolithic command was not resumable: a late failure restarted the full chain.

## PRE66 correction

PRE66 seals the clean reconstructed PRE65 runtime into `smarter-justice-v1.7.98-pre65-repaired-canonical-carrier.zip` and verifies both archive SHA-256 `9fe55452feb53d9e0360a366c08f54adbc15d6ff77ec23c8493f4d7790973bd9` and canonical tree SHA-256 `7b715fd80dc3677613add632bd1739774473ff4efad4eea6dafdfa3726bc7da9` before applying the single PRE66 overlay. The full replay remains an explicit audit path. Dependency installation and browser probing are bounded and receipted.

## Reproducibility defect repaired

PRE65 expected CSS fingerprint `3d22d5da3887dd79b3bbb988b6858e560ddcf854ca7ce5bc20a4d57454d8f2c1` did not match its clean one-instance overlay output `a1c9426bef0101f487ceaba54bd7002751398db5ce889cc89e191d664aceb6ce`. PRE66 corrects the expected fingerprint without changing those reconstructed CSS bytes and records the correction in a machine-readable receipt.

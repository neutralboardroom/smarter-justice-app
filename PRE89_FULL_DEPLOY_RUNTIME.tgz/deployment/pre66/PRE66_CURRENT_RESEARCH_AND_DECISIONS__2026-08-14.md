# PRE66 Current Research and Decisions — 2026-08-14

Primary technical references used for this nonlegal release:

- GitHub Actions workflow concurrency documentation: concurrency groups can cancel obsolete in-progress runs. https://docs.github.com/actions/using-jobs/using-concurrency
- Node.js 22 child-process documentation: spawned processes support explicit `timeout`, `killSignal`, and `AbortSignal` controls. https://nodejs.org/download/release/v22.17.0/docs/api/child_process.html
- Chrome Headless documentation: `--headless` and `--dump-dom` provide an unattended capability probe. https://developer.chrome.com/docs/chromium/headless
- npm CLI documentation: `npm ci` performs a clean, lockfile-bound install and exits rather than rewriting lock state. https://docs.npmjs.com/cli/v11/commands/npm-ci

Decisions: cancel obsolete PR-only qualification runs; use bounded Node subprocesses; keep browser probing separate from ordinary build; require locked nested dependencies in CI/Render but allow an explicit, truthful local skip for source-only qualification.

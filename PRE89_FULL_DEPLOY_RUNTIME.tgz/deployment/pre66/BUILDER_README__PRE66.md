# Smarter Justice PRE66 Builder Readme

PRE66 replaces the repeated ordinary replay of the sealed v1.7.98 base plus more than one hundred serial historical commands with a hash-verified canonical PRE65 runtime carrier. It preserves the complete historical replay under `npm run rebuild:full-history`.

## Default execution

```sh
SJ_RUNTIME_INSTALL_MODE=skip npm run rebuild:fast
npm run qualify:pre66
```

Use `SJ_RUNTIME_INSTALL_MODE=required` for a deployable runtime with locked production dependencies. CI and Render automatically treat `auto` as required.

## Boundaries

PRE64 compliance surfaces remain protected and its qualified legal/ethics, privacy, and accessibility review remains pending. PRE66 does not merge GitHub `main`, trigger Render, promote PRE64, or claim browser visual acceptance.

## Mandatory handoff

All three PRE66 ZIPs must be delivered together. Missing product, evidence, or builder/continuation fails closed.

# PRE71 Next Version Improvement List

1. Obtain qualified legal/ethics, privacy, accessibility, and metadata review for the four protected PRE64/PRE68 surfaces; change them only through an evidence-backed review disposition.
2. Resolve the two provider-topology failures through an explicit owner-approved production architecture decision, without exposing secrets or weakening fail-closed configuration checks.
3. Execute the pinned PRE70 receipt-chain workflow on an authorized exact Git commit and add signed GitHub artifact attestations only after successful remote verification.
4. Add a compact cross-release receipt-chain index that links PRE65 through PRE70 three-deliverable identities without embedding redundant product archives.
5. Add human browser/accessibility review dispositions for the representative route matrix while preserving automated evidence as non-conformance evidence only.

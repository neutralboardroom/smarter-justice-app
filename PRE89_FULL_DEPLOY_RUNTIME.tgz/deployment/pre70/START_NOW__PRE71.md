# START NOW — Smarter Justice PRE71

Use the three exact PRE70 deliverables as the only authoritative starting handoff. Verify their exact artifact identities and fail closed on any missing, corrupt, duplicate-byte, substituted, or mismatched role. Execute the continuation instructions in `CONTINUATION_AND_RELEASE_HANDOFF__PRE70.md` without waiting for another command.

Build one material `v2.0.0-pre71` review-ready candidate. Preserve the durable three-deliverable contract, protected-surface hashes, fast canonical-carrier path, full-history audit path, exact 166-test aggregate, seven persisted child receipts, independent anti-relabeling verifier, 18-render matrix, truthful six-failure boundary, and no-mutation GitHub/Render rule.

Deliver exactly:

1. `SMARTER_JUSTICE_PRE71_PRODUCT_SOURCE__<current-date>.zip`
2. `SMARTER_JUSTICE_PRE71_EVIDENCE_RECEIPTS__<current-date>.zip`
3. `SMARTER_JUSTICE_PRE71_BUILDER_CONTINUATION__<current-date>.zip`

One or two artifacts is a failed release.

# PRE70 Known Limitations

- Six inherited failures remain unresolved and are not treated as passed: four protected review-dependent surface assertions and two provider-topology assumptions.
- Local SHA-256 receipt-chain verification is not a digital signature, trusted timestamp, GitHub artifact attestation, or SLSA conformance claim.
- Locked runtime dependencies are not installed during source-only local qualification when `SJ_RUNTIME_INSTALL_MODE=skip` is selected.
- The pinned GitHub workflow is encoded but not executed in this build.
- Static browser evidence is not WCAG conformance and does not replace knowledgeable human accessibility review.
- No GitHub branch, pull request, workflow execution, `main` mutation, Render configuration change, production deployment, or promotion is authorized or claimed.

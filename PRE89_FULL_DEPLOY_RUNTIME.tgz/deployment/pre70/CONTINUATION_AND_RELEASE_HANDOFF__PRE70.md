# PRE70 Continuation and Release Handoff

The next build must start from all three exact PRE70 artifacts together. Verify exact basenames, byte sizes, SHA-256 values, ZIP integrity, distinct role bytes, embedded Product/Evidence identities, canonical-carrier identity, and the PRE70 segment-receipt-chain verification before any work. Missing, substituted, corrupt, duplicate-byte, cross-workspace, or unverifiable roles fail closed.

Build only `v2.0.0-pre71`. Preserve every working route, tool, profile, growth path, public-help feature, professional-value feature, brand asset, data boundary, privacy/security control, and accepted evidence unless a tested evidence-backed improvement requires a change.

Preserve the exact protected PRE64 surfaces and authoritative professional-membership page until qualified review explicitly supersedes them. Preserve the unchanged 166-command aggregate audit, seven child-process-isolated segments, exact six unresolved failures, 18-render phone/desktop matrix, fast verified carrier, full-history audit command, independent receipt-chain verifier, and durable three-deliverable rule.

First seek qualified resolution of the four protected-surface failures and an owner-approved architecture decision for the two provider-topology failures. If that authority is unavailable, do not weaken the gates or relabel failures. Pursue the highest-value independent improvement from the PRE71 improvement list.

Do not modify GitHub `main`, create or merge a pull request, execute a mutation-bearing workflow, change Render configuration or environment variables, deploy, or promote without Roger's exact product-scoped authorization and all applicable gates.

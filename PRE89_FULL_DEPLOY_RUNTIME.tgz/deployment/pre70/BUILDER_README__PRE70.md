# Smarter Justice PRE70 Builder Readme

PRE70 is a review-ready candidate built from the exact PRE69 three-artifact handoff. Ordinary reconstruction uses the SHA-256-verified PRE69 canonical runtime carrier and applies only the PRE70 overlay. The complete historical replay remains available as `npm run rebuild:full-history`.

Focused source qualification:

```bash
SJ_RUNTIME_INSTALL_MODE=skip npm run rebuild:fast
npm run qualify:pre70
```

Complete seven-process diagnostic, which records all failures without claiming acceptance:

```bash
npm run diagnose:segments:pre70
```

Independent verification of the frozen parent and seven child receipts:

```bash
npm run verify:segment-receipts:pre70
```

Static exact-source browser evidence:

```bash
npm run render:pre70
```

PRE70 local SHA-256 verification is not a digital signature, trusted timestamp, GitHub artifact attestation, SLSA conformance claim, live-route execution, deployment evidence, or production acceptance. All three PRE70 deliverables are mandatory together.

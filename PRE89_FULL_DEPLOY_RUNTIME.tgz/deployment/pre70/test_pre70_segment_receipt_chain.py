#!/usr/bin/env python3
"""Independent PRE70 receipt-chain qualification and deliberate fail-closed cases."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile

RUNTIME = pathlib.Path(os.environ.get("RUNTIME", ".runtime/smarter-justice-v1.7.98")).resolve()
SOURCE = pathlib.Path(__file__).resolve().parents[2]
VERIFIER = SOURCE / "scripts" / "verify-pre70-segment-receipt-chain.js"
CONTRACT_REL = pathlib.Path("deployment/pre70/SEGMENT_RECEIPT_CHAIN_CONTRACT__PRE70.json")


def load(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(path: pathlib.Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ordered_set_sha(child_runs: list[dict]) -> str:
    rows = [
        {
            "id": item.get("id"),
            "segmentIndex": item.get("segmentIndex"),
            "receiptBasename": item.get("receiptBasename"),
            "receiptSizeBytes": item.get("receiptSizeBytes"),
            "receiptSha256": item.get("receiptSha256"),
        }
        for item in child_runs
    ]
    return sha_bytes(json.dumps(rows, separators=(",", ":")).encode("utf-8"))


def run_verify(root: pathlib.Path) -> tuple[int, dict]:
    proc = subprocess.run(
        ["node", str(VERIFIER), "--root", str(root)],
        cwd=SOURCE,
        text=True,
        capture_output=True,
        timeout=30,
        check=False,
    )
    try:
        payload = json.loads(proc.stdout)
    except Exception as exc:  # pragma: no cover - diagnostic path
        raise AssertionError(f"verifier emitted invalid JSON: {exc}\nstdout={proc.stdout}\nstderr={proc.stderr}") from exc
    return proc.returncode, payload


def update_child_binding(root: pathlib.Path, parent: dict, index: int, child: dict, child_path: pathlib.Path) -> None:
    write(child_path, child)
    data = child_path.read_bytes()
    parent["childRuns"][index]["receiptSizeBytes"] = len(data)
    parent["childRuns"][index]["receiptSha256"] = sha_bytes(data)
    parent["segments"][index] = copy.deepcopy(child["segments"][0])
    parent["chain"]["childReceiptSetSha256"] = ordered_set_sha(parent["childRuns"])
    write(root / "deployment/pre70/PRE70_SEGMENTED_RUNTIME_TEST_RECEIPT__2026-08-15.json", parent)


def expect_failure(base: pathlib.Path, label: str, mutate, expected_fragment: str) -> dict:
    with tempfile.TemporaryDirectory(prefix=f"sj-pre70-{label}-") as temp_name:
        temp = pathlib.Path(temp_name)
        shutil.copytree(base / "deployment", temp / "deployment")
        mutate(temp)
        code, payload = run_verify(temp)
        assert code != 0, f"{label} unexpectedly passed"
        errors = payload.get("errors") or []
        assert any(expected_fragment in item for item in errors), f"{label} did not report {expected_fragment}: {errors}"
        return {"case": label, "failedClosed": True, "reportedCode": expected_fragment}


def main() -> int:
    contract = load(RUNTIME / CONTRACT_REL)
    assert contract["release"] == "v2.0.0-pre70"
    assert contract["status"] == "DURABLE__FAIL_CLOSED__NO_DRIFT"
    assert contract["expectedSegmentCount"] == 7
    assert contract["expectedTestCount"] == 166
    assert contract["signatureBoundary"]["cryptographicSignatureClaimed"] is False
    parent_path = RUNTIME / contract["parentReceipt"]
    if not parent_path.exists():
        assert os.environ.get("PRE70_BOOTSTRAP_ALLOW_MISSING_RECEIPTS") == "1", "frozen PRE70 parent receipt missing"
        print(json.dumps({"ok": True, "release": "v2.0.0-pre70", "bootstrapPending": True}))
        return 0

    code, baseline = run_verify(RUNTIME)
    assert code == 0 and baseline.get("ok") is True, baseline
    assert baseline["totals"] == {"expected": 166, "executed": 166, "passed": 160, "failed": 6, "timedOut": 0}
    parent = load(parent_path)
    child_dir_rel = pathlib.Path(parent["chain"]["childReceiptDirectory"])

    def child_path(root: pathlib.Path, index: int) -> pathlib.Path:
        local_parent = load(root / contract["parentReceipt"])
        return root / pathlib.Path(local_parent["chain"]["childReceiptDirectory"]) / local_parent["childRuns"][index]["receiptBasename"]

    cases = []
    cases.append(expect_failure(RUNTIME, "missing-child", lambda root: child_path(root, 0).unlink(), "CHILD_UNREADABLE"))
    cases.append(expect_failure(RUNTIME, "duplicate-child-bytes", lambda root: child_path(root, 1).write_bytes(child_path(root, 0).read_bytes()), "DUPLICATE_CHILD_BYTES"))

    def tamper(root: pathlib.Path) -> None:
        p = child_path(root, 0)
        doc = load(p)
        doc["generatedAt"] = "2099-01-01T00:00:00.000Z"
        write(p, doc)
    cases.append(expect_failure(RUNTIME, "tampered-child-hash", tamper, "TAMPERED_CHILD_HASH"))

    def relabel(root: pathlib.Path) -> None:
        local_parent_path = root / contract["parentReceipt"]
        local_parent = load(local_parent_path)
        for index, run in enumerate(local_parent["childRuns"]):
            p = root / pathlib.Path(local_parent["chain"]["childReceiptDirectory"]) / run["receiptBasename"]
            child = load(p)
            failed = next((row for row in child["segments"][0]["tests"] if row["status"] == "FAIL"), None)
            if failed:
                failed["status"] = "PASS"
                update_child_binding(root, local_parent, index, child, p)
                return
        raise AssertionError("no failed child row found")
    cases.append(expect_failure(RUNTIME, "failure-relabel", relabel, "FAILURE_RELABELED_AS_PASS"))

    def reorder(root: pathlib.Path) -> None:
        local_parent = load(root / contract["parentReceipt"])
        p = child_path(root, 0)
        child = load(p)
        child["segments"][0]["tests"][0], child["segments"][0]["tests"][1] = child["segments"][0]["tests"][1], child["segments"][0]["tests"][0]
        update_child_binding(root, local_parent, 0, child, p)
    cases.append(expect_failure(RUNTIME, "test-order-mismatch", reorder, "TEST_ORDER_MISMATCH"))

    def truncate(root: pathlib.Path) -> None:
        local_parent = load(root / contract["parentReceipt"])
        p = child_path(root, 0)
        child = load(p)
        child["segments"][0]["tests"].pop()
        update_child_binding(root, local_parent, 0, child, p)
    cases.append(expect_failure(RUNTIME, "coverage-truncation", truncate, "TEST_ORDER_MISMATCH"))

    def overclaim(root: pathlib.Path) -> None:
        p = root / contract["parentReceipt"]
        doc = load(p)
        doc["suitePass"] = True
        doc["releaseAcceptanceClaimed"] = True
        write(p, doc)
    cases.append(expect_failure(RUNTIME, "acceptance-overclaim", overclaim, "ACCEPTANCE_OVERCLAIM"))

    result = {
        "ok": True,
        "release": "v2.0.0-pre70",
        "baselineVerified": True,
        "baselineTotals": baseline["totals"],
        "negativeCases": cases,
        "signatureClaimed": False,
        "slsaConformanceClaimed": False,
    }
    output = RUNTIME / "deployment/pre70/PRE70_SEGMENT_RECEIPT_CHAIN_NEGATIVE_QUALIFICATION__2026-08-15.json"
    write(output, result)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

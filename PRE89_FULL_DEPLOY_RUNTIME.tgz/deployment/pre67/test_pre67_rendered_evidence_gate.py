import hashlib
import json
import os
import pathlib
import re
import unittest
import zipfile

ROOT = pathlib.Path(os.environ.get('RUNTIME', '.runtime/smarter-justice-v1.7.98')).resolve()
SOURCE = pathlib.Path(__file__).resolve().parents[2]
EVIDENCE = pathlib.Path(os.environ['PRE67_EVIDENCE_DIR']).resolve() if os.environ.get('PRE67_EVIDENCE_DIR') else None


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


class Pre67RenderedEvidenceGate(unittest.TestCase):
    def test_release_and_protected_surfaces(self):
        server = (ROOT / 'server.js').read_text()
        self.assertIn("currentPlatformRelease:'v2.0.0-pre67'", server)
        self.assertIn("platformMarker:'SMARTER_JUSTICE_PRE67_RENDERED_EVIDENCE_GATE'", server)
        expected = {
            'public/attorney-partner-tour.html': 'eada21a990bddbc27e6bcfee271a23b7e387e4ec33711993494cacc6479a8449',
            'public/professional-responsibility.html': 'fa06a395f992e88817bce057066ac13adc93f816916818a1e242186ef786228c',
            'public/styles.css': 'a1c9426bef0101f487ceaba54bd7002751398db5ce889cc89e191d664aceb6ce',
        }
        for relative, wanted in expected.items():
            self.assertEqual(sha(ROOT / relative), wanted, relative)
        responsibility = (ROOT / 'public/professional-responsibility.html').read_text()
        self.assertIn('qualified legal/ethics, privacy, and accessibility review', responsibility)

    def test_fast_pre66_carrier_and_full_history_audit(self):
        package = json.loads((SOURCE / 'package.json').read_text())
        scripts = package['scripts']
        for name in ('postinstall', 'rebuild:fast'):
            self.assertIn('bootstrap-pre67-fast-carrier.js', scripts[name])
            self.assertIn('apply-pre67-rendered-evidence-gate.js', scripts[name])
            self.assertNotIn('bootstrap-sitewide-release.js', scripts[name])
            self.assertNotIn('apply-pre66-fast-verified-carrier.js', scripts[name])
        self.assertIn('bootstrap-sitewide-release.js', scripts['rebuild:full-history'])
        self.assertIn('apply-pre65-three-deliverable-contract.js', scripts['rebuild:full-history'])
        self.assertIn('apply-pre66-fast-verified-carrier.js', scripts['rebuild:full-history'])
        self.assertIn('apply-pre67-rendered-evidence-gate.js', scripts['rebuild:full-history'])

    def test_carrier_binding(self):
        manifest = json.loads((SOURCE / 'deployment/pre67/PRE67_CARRIER_MANIFEST__2026-08-14.json').read_text())
        archive = SOURCE / manifest['archive']
        self.assertEqual(archive.stat().st_size, manifest['archiveSizeBytes'])
        self.assertEqual(sha(archive), manifest['archiveSha256'])
        with zipfile.ZipFile(archive) as handle:
            files = [name for name in handle.namelist() if not name.endswith('/')]
        self.assertEqual(len(files), manifest['fileCount'])
        self.assertEqual(manifest['treeSha256'], 'a7a3c1017af79d05e7717e470780aca3799dfcd0694a0bd9368b52d86aeca749')

    def test_contract_and_durable_rules(self):
        contract = json.loads((ROOT / 'deployment/pre67/RENDERED_EVIDENCE_CONTRACT__PRE67.json').read_text())
        self.assertEqual(contract['status'], 'DURABLE__NON_OPTIONAL__NO_DRIFT')
        self.assertEqual([item['role'] for item in contract['requiredDeliverables']], [
            'PRODUCT_SOURCE', 'EVIDENCE_RECEIPTS', 'BUILDER_CONTINUATION'
        ])
        self.assertEqual(contract['renderMatrix']['requiredRenderCount'], 16)
        self.assertFalse(contract['evidenceTiers']['localStaticExactSource']['acceptanceClaimed'])
        self.assertFalse(contract['evidenceTiers']['ciLiveRoute']['productionAcceptanceClaimed'])
        agents = (ROOT / 'AGENTS.md').read_text()
        for rule in ('DURABLE THREE-DELIVERABLE RULE', 'DURABLE FAST VERIFIED BUILD RULE', 'DURABLE RENDERED-EVIDENCE RULE'):
            self.assertIn(rule, agents)

    def test_version_matched_workflow_and_privacy_boundaries(self):
        self.assertEqual((SOURCE / 'requirements-pre67-visual.txt').read_text().strip(), 'playwright==1.57.0')
        workflow = (SOURCE / '.github/workflows/pre67-rendered-evidence.yml').read_text()
        self.assertIn('mcr.microsoft.com/playwright/python:v1.57.0-noble', workflow)
        self.assertNotRegex(workflow, r'playwright/python:latest')
        self.assertIn('retention-days: 14', workflow)
        self.assertIn('render-pre67-browser-evidence.py', workflow)
        self.assertNotRegex(workflow.lower(), r'\btrace\b|\bvideo\b')
        for exact_action in (
            'actions/checkout@d23441a48e516b6c34aea4fa41551a30e30af803',
            'actions/setup-node@48b55a011bda9f5d6aeb4c2d9c7362e8dae4041e',
            'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02',
        ):
            self.assertIn(exact_action, workflow)

    @unittest.skipUnless(EVIDENCE, 'PRE67_EVIDENCE_DIR not supplied')
    def test_bound_evidence_directory(self):
        receipt = json.loads((EVIDENCE / 'PRE67_RENDERED_BROWSER_EVIDENCE_RECEIPT__2026-08-14.json').read_text())
        self.assertEqual(receipt['release'], 'v2.0.0-pre67')
        self.assertTrue(receipt['renderComplete'])
        self.assertEqual(receipt['expectedRenderCount'], 16)
        self.assertEqual(receipt['completedRenderCount'], 16)
        self.assertEqual(receipt['automatedFindingCount'], 0)
        self.assertEqual(receipt['infrastructureFailures'], [])
        self.assertFalse(receipt['evidenceBoundary']['productionAcceptanceClaimed'])
        if receipt['mode'] == 'STATIC':
            self.assertEqual(receipt['status'], 'STATIC_EXACT_SOURCE_BROWSER_EVIDENCE_COMPLETE')
            self.assertFalse(receipt['evidenceBoundary']['liveRouteAcceptanceClaimed'])
        else:
            self.assertEqual(receipt['status'], 'LIVE_ROUTE_RENDER_GATE_PASS')
            self.assertTrue(receipt['strictGatePass'])
        screenshots = [item['screenshot'] for item in receipt['results'] if item.get('screenshot')]
        self.assertEqual(len(screenshots), 16)
        for item in screenshots:
            file = EVIDENCE / item['relativePath']
            self.assertEqual(file.stat().st_size, item['sizeBytes'])
            self.assertEqual(sha(file), item['sha256'])


if __name__ == '__main__':
    unittest.main()

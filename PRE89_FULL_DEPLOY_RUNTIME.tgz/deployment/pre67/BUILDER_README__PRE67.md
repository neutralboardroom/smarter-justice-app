# Smarter Justice PRE67 Builder Readme

PRE67 uses a deterministic canonical PRE66 runtime carrier and applies only the PRE67 rendered-evidence overlay during ordinary builds. The complete historical reconstruction remains available as an explicit audit path.

## Default source qualification

```sh
SJ_RUNTIME_INSTALL_MODE=skip npm run rebuild:fast
npm run qualify:pre67
PRE67_EVIDENCE_DIR=/path/to/static-evidence npm run qualify:pre67
```

## Local rendered review

```sh
npm run render:static:pre67
PRE67_EVIDENCE_DIR=.pre67-rendered-evidence/static npm run qualify:pre67
```

Static mode is review evidence only. It removes scripts, blocks network requests, and does not claim live-route, production, or accessibility acceptance.

## Deployable and CI mode

Use `SJ_RUNTIME_INSTALL_MODE=required` for locked runtime dependencies. The PRE67 GitHub Actions workflow uses `mcr.microsoft.com/playwright/python:v1.57.0-noble` with `playwright==1.57.0`, starts the candidate, and runs the strict live-route matrix. Production still requires explicit authorization and post-deployment verification.

## Mandatory handoff

Deliver Product Source, Evidence & Receipts, and Builder & Continuation ZIPs together with exact basename, size, and SHA-256. Any missing or substituted role fails closed.

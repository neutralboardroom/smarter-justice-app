# PRE67 Build and Browser Diagnosis

## Why the previous browser work was slow and unproductive

The PRE66 probe launched the managed system Chromium binary and waited for URL-based headless output. The application itself starts and returns a healthy `/health` response, but system Chromium blocks local URL navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. Waiting longer cannot turn that managed-policy result into valid acceptance evidence.

## PRE67 correction

PRE67 separates build, local review evidence, CI route evidence, and production evidence:

1. The ordinary build extracts a hash-verified canonical PRE66 carrier and applies only the PRE67 overlay.
2. Local static mode uses Chromium `set_content` with exact candidate HTML, inlined candidate CSS/images, no network, and scripts removed. It produces actual screenshots without modifying or bypassing browser policy.
3. CI live mode uses a version-matched Playwright browser image, starts the candidate, navigates representative routes sequentially, and applies strict route/render checks.
4. Production still requires authorized post-deployment route and screenshot verification.

This approach removes the unproductive raw-probe wait from ordinary builds, produces useful evidence now, and fails closed rather than relabeling static evidence as live acceptance.

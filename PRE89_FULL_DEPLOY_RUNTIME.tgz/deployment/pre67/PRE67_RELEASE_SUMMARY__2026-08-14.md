# Smarter Justice PRE67 Release Summary

PRE67 replaces PRE66’s timeout-only raw-Chromium capability probe with a deterministic rendered-evidence system. It produced 16 full-page Chromium screenshots across eight representative public and professional routes at phone and desktop viewports, bound every screenshot by size and SHA-256, and recorded zero automated structure, accessible-name, form-label, duplicate-ID, route-selector, or document-overflow findings.

The evidence is deliberately tiered. Local static mode renders exact candidate HTML, CSS, and images without URL navigation or application scripts and is review evidence only. A new GitHub Actions gate uses a version-matched Playwright Python image and package to start the candidate, navigate live local routes, run sequential checks, and retain privacy-minimized evidence for 14 days. Neither tier is represented as production or WCAG acceptance.

PRE67 also creates a deterministic canonical PRE66 carrier. The ordinary source-only rebuild completed in 4.645 seconds and applies only the PRE67 overlay; the full historical replay remains available as `npm run rebuild:full-history`. The separate browser matrix completed in 20.699 seconds and is not added to every ordinary build.

No public interface was changed. Manual review found no material regression or evidence-backed reason to alter working pages merely for novelty. All three protected PRE64 surfaces remain byte-identical, and the qualified legal/ethics, privacy, and accessibility review remains pending.

GitHub `main`, pull requests, Render configuration, and production were not changed. The inherited aggregate suite still stops on the stale exact-homepage-wording assertion recorded in `PRE67_BROAD_REGRESSION_LIMITS__2026-08-14.json`.

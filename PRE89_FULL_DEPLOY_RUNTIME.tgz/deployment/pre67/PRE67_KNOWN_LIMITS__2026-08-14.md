# PRE67 Known Limits

- PRE64 qualified legal/ethics, privacy, and accessibility review remains pending. PRE67 preserves its protected pages and CSS byte-for-byte.
- Local static evidence removes application scripts and does not navigate server routes. It does not test dynamic menus, form submission, APIs, authentication, payments, storage, or production integrations.
- Managed local Chromium blocks URL navigation. PRE67 does not modify or bypass that policy; the live-route matrix is encoded for a version-matched CI browser environment and has not been executed through GitHub in this source-only build.
- Locked runtime dependencies were not installed during local source qualification. CI and Render required mode remain fail-closed and bounded.
- The inherited aggregate runtime suite stops on a stale exact-homepage-wording assertion. PRE67 did not change accepted public wording merely to satisfy the obsolete phrase check.
- No GitHub branch, pull request, merge, Render configuration change, or deployment occurred.
- Static and CI candidate evidence do not establish production acceptance, WCAG conformance, or legal/privacy compliance.

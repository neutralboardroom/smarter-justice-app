# Smarter Justice PRE67 Continuation and Release Handoff

The authoritative next base is the exact PRE67 Product Source ZIP identified in the detached final artifact manifest. The next chat must also receive the matching PRE67 Evidence & Receipts and Builder & Continuation ZIPs; one or two files fail closed.

Verify all three immutable basenames, sizes, and SHA-256 values before changing source. Bootstrap from the PRE67 canonical carrier path and apply only the next overlay during ordinary work. Preserve `npm run rebuild:full-history` as the explicit historical audit command.

Preserve the durable rendered-evidence distinction among static exact-source review, CI live-route evidence, and post-deployment evidence. Do not call one tier another. Keep screenshots free of user, matter, credential, and private operational data.

PRE64 qualified legal/ethics, privacy, and accessibility review remains pending. Until a qualified receipt is supplied and validated, preserve the attorney-tour HTML, professional-responsibility HTML, and canonical CSS bytes exactly.

GitHub `main`, pull requests, Render configuration, and production remain unchanged by PRE67. Future deployment requires Roger’s explicit product-scoped authorization and all promotion gates.

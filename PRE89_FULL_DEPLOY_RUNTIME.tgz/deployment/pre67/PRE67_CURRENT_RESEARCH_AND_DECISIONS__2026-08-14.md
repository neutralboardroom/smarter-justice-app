# PRE67 Current Research and Decisions — 2026-08-14

## Technical and accessibility sources

- Playwright Python Docker documentation — the official image includes browsers and system dependencies, the Python package must be installed separately, and the image and project versions should match: https://playwright.dev/python/docs/docker
- Playwright CI guidance — use a browser-capable CI environment and run sequentially when stability and reproducibility matter: https://playwright.dev/python/docs/ci-intro and https://playwright.dev/docs/ci
- Playwright screenshot guidance — the API supports full-page screenshots of the complete scrollable page: https://playwright.dev/python/docs/screenshots
- W3C WCAG 2 overview and supporting documents — WCAG 2.2 is the latest WCAG 2 recommendation, and the Quick Reference is a practical checklist; automated checks alone do not establish conformance: https://www.w3.org/WAI/standards-guidelines/wcag/ and https://www.w3.org/WAI/standards-guidelines/wcag/docs/
- GitHub Actions artifact-retention guidance — workflow artifacts can use a custom retention period within repository or organization limits: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository

## Public legal-help, directory, and professional-platform review

- Clio publicly describes intake forms, appointment booking, workflow automation, CRM, e-signatures, pipeline visibility, and reporting: https://www.clio.com/features/online-intake-forms/ and https://www.clio.com/features/legal-workflow-automation-software/
- Justia publicly describes free attorney profiles, claiming and updating, firm-email verification, practice/location discovery, and profile hiding/deletion controls: https://lawyers.justia.com/faq and https://www.justia.com/lawyers
- Avvo publicly describes profiles populated from public sources, free claiming and updating, correction pathways, reviews, and a separate rating model: https://support.avvo.com/hc/en-us/articles/208463046-How-does-Avvo-get-information-about-lawyers and https://support.avvo.com/hc/en-us/articles/208463066-How-do-I-claim-my-profile

## Decisions

### ADOPT — deterministic representative-route evidence

Adopt a fixed matrix spanning the public home/start path, help comparison, legal-area directory, community resources, professional directory, professional workspace, attorney tour, and professional-responsibility page. Render every route at a 390×844 phone viewport and 1440×1000 desktop viewport. Record full-page screenshots, SHA-256 values, document structure, accessible naming, duplicate IDs, horizontal overflow, and expected funnel selectors.

### ADOPT — version-matched browser CI environment

Use `playwright==1.57.0` with `mcr.microsoft.com/playwright/python:v1.57.0-noble`, matching the known-good package available for this build. Forbid `latest` tags. Run the route matrix sequentially, bound process and navigation time, and retain the privacy-minimized artifact for 14 days.

### ADAPT — transparent profile and funnel continuity

Directory competitors demonstrate the value of clear find/claim/update paths and source/currentness transparency. Smarter Justice already separates professional identity, registration evidence, claim state, specialty acceptance, membership, and visibility. PRE67 therefore tests that those existing routes and calls to action remain present rather than adding a rating, review, or pay-to-rank model.

### DEFER — deeper paid intake and CRM execution

Automated scheduling, messaging, intake pipelines, e-signatures, and end-to-end client CRM can create professional value, but they require separate privacy, security, consent, legal, operational, storage, and production gates. PRE67 does not represent those functions as live merely because competitors offer them.

### REJECT — unsupported ranking, guaranteed leads, or verification-for-payment

Do not add or imply paid verification, paid rank, guaranteed clients, guaranteed revenue, or blanket compliance. Preserve the PRE64 responsibility boundaries and the existing separation among membership, evidence, verification, visibility, advertising review, and professional judgment.

## Version decision

PRE67 makes a material evidence and release-control improvement without changing protected PRE64 public bytes or altering the interface merely for novelty. Static exact-source screenshots are produced now because the managed local browser blocks URL navigation. The live-route gate is encoded for a version-matched CI browser environment. Neither tier is mislabeled as production or qualified accessibility acceptance.

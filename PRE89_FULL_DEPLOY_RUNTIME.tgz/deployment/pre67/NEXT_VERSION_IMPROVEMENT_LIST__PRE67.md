# PRE67 Next Version Improvement List

1. Consume and validate a qualified PRE64 legal/ethics, privacy, and accessibility review receipt when available; otherwise continue preserving the protected surfaces unchanged.
2. Execute the PRE67 live-route rendered-evidence workflow on an exact GitHub commit and bind the workflow run, screenshot manifest, and result to the next promotion candidate.
3. Replace the inherited homepage exact-phrase assertion with semantic, route-aware public/professional funnel checks, then segment the large aggregate suite into independently cached gates while retaining one aggregate command.
4. Add bounded live interaction checks for the mobile menu, public story-route form, directory filters, community plan, marketing preflight, and attorney-tour controls without collecting user or matter data.
5. Promote carrier and three-deliverable manifests to owner-approved signed provenance when a signing key, protected workflow, and durable external evidence store are authorized.

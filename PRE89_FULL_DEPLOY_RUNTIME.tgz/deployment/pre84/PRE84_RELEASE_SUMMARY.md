# Smarter Justice PRE84 Release Summary

PRE84 advances the PRE83 Attorney Profile Factory integration from a one-time full-scale import path into a release-neutral, restart-safe, transactional refresh lifecycle.

Material improvements:

- accepts compatible future Factory releases by contract/schema/hash semantics rather than hard-coding Factory v0.21.0;
- preserves the exact current 9,946-attorney + 481-firm baseline;
- distinguishes CREATED, UNCHANGED, REFRESHED, HELD_NEWER_JUSTICE_STATE, MISSING_FROM_FACTORY_REQUIRES_REVIEW, and HELD_MISSING_SOURCE_NEWER_JUSTICE_STATE;
- never automatically deletes or suppresses a Justice identity merely because it disappears from a later Factory snapshot;
- proves Justice corrections survive process restart, same-snapshot replay, compatible successor refresh, and successor replay;
- reconciles current firm rosters from canonical APF relationships without allowing payment to claim attorney identities;
- adds an explicit Roger Rule permanence/no-loss rule and a hash-based preservation gate for the inherited authority corpus;
- adds bounded `rebuild:current` and current-runtime qualification commands so successor builders do not confuse historical protected hashes with current runtime truth.

Truth remains `QUALIFIED_NONPRODUCTION / CHECKOUT_TEST_READY`. No authenticated Stripe provider proof, managed production PostgreSQL qualification, production database import, live billing, live outreach, live Member Care delivery, or live deployment is claimed.

UX/UI and AI Navigator material improvements added before final sealing:

- promotes AI Navigator into a first-class homepage and primary-navigation path;
- removes stale `v2.0.0-pre43` and provider-oriented customer language from Navigator;
- gives public users and lawyers explicit entry modes instead of one generic tool wall;
- adds clearer task modes, examples, copy support, character count, start-over behavior, privacy guidance, and consequential-action boundaries;
- separates public `Find a lawyer` from lawyer `Find my profile` / `For lawyers` paths;
- applies restrained global action/card/form geometry, focus treatment, reduced-motion and forced-colors guardrails;
- qualifies the flagship homepage and Navigator with 42 source assertions plus 33 rendered/mobile interaction assertions at 390px and 1440px;
- carries a durable owner UX/UI + AI Navigator standard into successors without weakening no-loss, accessibility, privacy, legal, or nonproduction truth.

Rendered evidence is a local browser spot check, not a production-route or WCAG-conformance claim.

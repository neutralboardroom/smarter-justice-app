# PRE73 Next Version Improvement List

1. Complete claim authority verification → webhook-confirmed subscription entitlement → customer portal cancellation qualification end to end.
2. Obtain qualified review for the protected professional-membership surface before reconciling its inherited legacy copy.
3. Build organization-first roster previews and collision-safe Team/Office acquisition for high-confidence firms.
4. Add measured attribution for preview → claim → plan → checkout once deployment/live traffic is authorized.
5. Continue three-idea acquisition research and attack the highest safe P0/P1 growth bottleneck.

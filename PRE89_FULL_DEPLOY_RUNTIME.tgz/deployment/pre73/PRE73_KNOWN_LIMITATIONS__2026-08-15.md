# PRE73 Known Limitations

- The byte-protected professional-membership surface remains held for qualified legal/ethics/privacy/accessibility review and was not changed.
- Live Stripe billing remains closed behind existing owner/provider/payment gates.
- Live outreach remains disabled pending sender authentication, suppression, compliance, and campaign authority.
- The new claim-to-plan preview is candidate functionality; no live conversion improvement is claimed before deployment and measured traffic.
- Existing inherited protected/provider failures remain separately governed; PRE73 does not relabel them as passes.

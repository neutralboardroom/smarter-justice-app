'use strict';
module.exports={
  "schema": "smarter-justice-current-release-truth",
  "schemaVersion": "1.4.0",
  "releaseVersion": "1.7.85",
  "generatedAt": "2026-08-04T18:21:00-04:00",
  "selectedBase": {
    "filename": "smarter-justice-v1.7.84.zip",
    "version": "1.7.84",
    "sha256": "68c7816364ee71b7f191560ec6b81b6c03762bc9583be6fc1f22dc6670040712",
    "sizeBytes": 8939904,
    "entries": 3209,
    "files": 3185,
    "directories": 24,
    "uncompressedBytes": 26509881,
    "compressedBytes": 8451856,
    "payloadInventoryRecords": 3182,
    "payloadInventorySha256": "30106f114abbd2f7f29983c83ff99279987f16269da6ede2ca20c35300750666",
    "inventoryRecords": 3184,
    "inventorySha256": "ae89218b88910d88a29a9a80724556a4b93e6bffb0d8f84090285326936d40e9",
    "treeSha256": "ae89218b88910d88a29a9a80724556a4b93e6bffb0d8f84090285326936d40e9",
    "packageJsonSha256": "20c011399ddd5236b330921ab74f8f3082d2a23897c0dcab24e49df0a82e3cbf",
    "packageLockSha256": "cd669e7745b6c13791cf4a35fbbd0f059bc520c4aeed69d430ee9d98f7ee441a",
    "sbomSha256": "b9e8a25b0d59ca81f34aae580c5101f16cbd51d344340db37e3450b8baa5bc85",
    "dependencyIndependentParts": 147,
    "totalReadinessParts": 148,
    "testLogSha256": null
  },
  "rollbackArtifact": {
    "filename": "smarter-justice-v1.7.84.zip",
    "version": "1.7.84",
    "sha256": "68c7816364ee71b7f191560ec6b81b6c03762bc9583be6fc1f22dc6670040712",
    "sizeBytes": 8939904,
    "entries": 3209,
    "files": 3185,
    "directories": 24,
    "uncompressedBytes": 26509881,
    "compressedBytes": 8451856,
    "payloadInventoryRecords": 3182,
    "payloadInventorySha256": "30106f114abbd2f7f29983c83ff99279987f16269da6ede2ca20c35300750666",
    "inventoryRecords": 3184,
    "inventorySha256": "ae89218b88910d88a29a9a80724556a4b93e6bffb0d8f84090285326936d40e9",
    "treeSha256": "ae89218b88910d88a29a9a80724556a4b93e6bffb0d8f84090285326936d40e9",
    "packageJsonSha256": "20c011399ddd5236b330921ab74f8f3082d2a23897c0dcab24e49df0a82e3cbf",
    "packageLockSha256": "cd669e7745b6c13791cf4a35fbbd0f059bc520c4aeed69d430ee9d98f7ee441a",
    "sbomSha256": "b9e8a25b0d59ca81f34aae580c5101f16cbd51d344340db37e3450b8baa5bc85",
    "dependencyIndependentParts": 147,
    "totalReadinessParts": 148,
    "testLogSha256": null
  },
  "sourcePackage": {
    "filename": "smarter-justice-v1.7.85.zip",
    "version": "1.7.85",
    "dependencyIndependentParts": 153,
    "totalReadinessParts": 154,
    "identityState": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED",
    "packageJsonSha256": "90fa211652f8e1282fa48d097c56950ac24b7c52f009062699ff59fe0f4798d6",
    "packageLockSha256": "2f850a33744f17d97a75ae282639d6a2849128c513e82120eed01ad4cec04c19",
    "sbomSha256": "b7f6ecf40fa4c3cafa686faf7d10549775c9fb8b99723455191d0f7370a60c43"
  },
  "finalArchive": {
    "filename": "smarter-justice-v1.7.85.zip",
    "version": "1.7.85",
    "identityState": "REPORTED_AFTER_IMMUTABLE_PACKAGING",
    "sha256": null,
    "sizeBytes": null
  },
  "activeMasterPair": {
    "receiptId": "MPCR-2026-07-31-E1-R0-05F4296ED378",
    "transactionId": "MPPT-2026-07-31-SJ8-FP26-304CB87BF174",
    "pairEpoch": 1,
    "pairRevision": 0,
    "receiptSha256": "4dd826cb0f9d89e41528b9732f250899cab45ce89766ae7fdfdb8a44d48d906e",
    "centralMasterSha256": "89f49e1433d05a937a31c2144e42e408a94c4502d8c388ad5f3a6eae7ad5aa68",
    "portalFamilyMasterSha256": "fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f",
    "baselineId": "DRB-2026-07-31-DUR001-DUR043-V2",
    "semanticCapsuleSha256": "3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8"
  },
  "portalAuthority": {
    "record": "INITIAL_PORTAL_AUTHORITY_V1.7.75.json",
    "evidenceBoundary": "OWNER_RECORDED_OR_HANDOFF_RECORDED_NOT_CURRENT_CHAT_PORTAL_INSPECTION",
    "liveConnectionsOpened": false,
    "automaticWritesOpened": false
  },
  "ownerLaunchActionPacket": {
    "record": "OWNER_LAUNCH_ACTION_PACKET_V1.7.75.json",
    "state": "PRIVATE_VALIDATED_NONSECRET_EXECUTION_PACKET",
    "readyNowCount": 4
  },
  "production": {
    "lastVerifiedVersion": "1.6.1",
    "deploymentAuthorized": false,
    "deploymentState": "NOT_DEPLOYED",
    "deployed": false
  },
  "launchState": "NO_GO",
  "deploymentAuthorized": false,
  "publicDisplay": {
    "currentVersion": "1.7.85",
    "sourceAndRollback": "smarter-justice-v1.7.84.zip",
    "finalIdentity": "Reported after immutable packaging; never embedded in the ZIP",
    "promptPack": "V14 exact artifact binding, preview-only evidence transaction packaging, detached release-handoff verification, unified live operations, and non-self-referential release automation accepted locally; external live evidence remains separate.",
    "launch": "NO_GO",
    "deployment": "Not authorized",
    "sourceVersion": "1.7.84"
  },
  "validationState": "FINAL_SOURCE_SEALED_FINAL_ARCHIVE_PENDING",
  "currentPromptPack": {
    "packId": "SJP-2026-08-02-C15-P37-D11-V13",
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "canonicalCommitProven": false,
    "baselineId": "DRB-2026-08-02-DUR001-DUR086-V13",
    "ruleCount": 86,
    "deploymentFile4State": "PRESERVED_INSIDE_V14"
  },
  "candidateArtifact": {
    "filename": "smarter-justice-v1.7.85-candidate-a.zip",
    "sha256": "606fc2040beb360760986e4a41b92e8aad09d2331bf18f12af4b9c03be58774f",
    "sizeBytes": 9183739,
    "state": "CANDIDATE_ACCEPTED_TWO_DETERMINISTIC_BUILDS_TWO_FRESH_EXTRACTIONS"
  },
  "deploymentReadiness": {
    "record": "DEPLOYMENT_READINESS_V1.7.75.json",
    "state": "LOCAL_LAUNCH_DAY_ORCHESTRATION_ACCEPTED_ALL_PRODUCT_PREFLIGHT_PENDING"
  },
  "packId": "SJP-2026-08-02-C15-P37-D11-V13",
  "durableRuleBaseline": "DRB-2026-08-02-DUR001-DUR086-V13",
  "presealArtifact": {
    "candidateSha256": "606fc2040beb360760986e4a41b92e8aad09d2331bf18f12af4b9c03be58774f",
    "candidateSizeBytes": 9183739,
    "state": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED"
  },
  "recoveryLineage": {
    "record": "RECOVERY_LINEAGE_RECEIPT_V1.7.75.json",
    "inheritedExactRecoveryBase": "smarter-justice-v1.7.73.zip",
    "unavailableIntermediate": "smarter-justice-v1.7.74.zip",
    "byteExactIntermediateRecoveryClaimed": false,
    "currentExactSource": "smarter-justice-v1.7.84.zip"
  },
  "v12ContinuousImprovement": {
    "packetSha256": "37d90cab818b71613c388bf195b08d129eb569dd183de5358f32dd335975a1d5",
    "innovationPlan": "CONTINUOUS_SELF_IMPROVEMENT_AND_INNOVATION_PLAN_V1.7.85.json",
    "dualImprovementReport": "PRODUCT_AND_PROMPT_DUAL_IMPROVEMENT_REPORT_V1.7.85.json",
    "crossVersionLearning": "CROSS_VERSION_LEARNING_LEDGER_V1.7.85.json",
    "releaseEvidenceCoverageContract": "RELEASE_EVIDENCE_COVERAGE_CONTRACT_V1.7.85.json"
  },
  "workingTreeAcceptance": {
    "record": "WORKING_TREE_ACCEPTANCE_V1.7.85.json",
    "runs": 2,
    "identicalOutput": true,
    "testLogSha256": "d3ae23a30cace8652455cff0a34c5f9464169b07b526c84abae57170459a8333",
    "state": "FINALIZED_WORKING_TREE_ACCEPTED"
  },
  "candidateAcceptanceRecord": "CANDIDATE_ARTIFACT_ACCEPTANCE_V1.7.85.json",
  "finalSourceAcceptanceRecord": "FINAL_SOURCE_ACCEPTANCE_V1.7.85.json",
  "openAiLaunch": {
    "launchBatchId": "SJP-OPENAI-LIVE-2026-08-03-BATCH-02",
    "overlayCheckpoint": "OPENAI_LAUNCH_OVERLAY_CHECKPOINT_V1.7.85.json",
    "gatewayContract": "AI_GATEWAY_CONTRACT_V1.7.85.json",
    "modelConfiguration": "AI_MODEL_CONFIGURATION_V1.7.85.json",
    "toolPromptRegistry": "AI_TOOL_AND_PROMPT_REGISTRY_V1.7.85.json",
    "capabilityMatrix": "FIVE_PRODUCT_AI_CAPABILITY_MATRIX_V1.7.85.json",
    "vendorPolicy": "OPENAI_ONLY",
    "keyConfigured": false,
    "liveSmokePassed": false,
    "portalCompatibilityReceipts": 0,
    "deploymentAuthorized": false,
    "launchState": "NO_GO"
  },
  "v14": {
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "mode": "MODE_E_RECOVERY",
    "artifactBindingReceipt": "ARTIFACT_BINDING_AND_MODE_RECEIPT.json",
    "ownerReceipt": "OWNER_RECEIPT.txt",
    "releasePayloadInventory": "RELEASE_PAYLOAD_INVENTORY_SHA256.txt",
    "unifiedLiveOperations": "V14_UNIFIED_LIVE_OPERATIONS_REGISTER_V1.7.85.json",
    "finalDeliveryIdentity": "REPORTED_AFTER_PACKAGING",
    "liveEvidenceConnector": "V14_LIVE_EVIDENCE_CONNECTOR_CONTRACT_V1.7.85.json",
    "receiptAutomation": "V14_RELEASE_RECEIPT_AUTOMATION_V1.7.85.json",
    "evidenceBatchWorkspace": "V14_EVIDENCE_BATCH_WORKSPACE_CONTRACT_V1.7.85.json",
    "detachedDeliveryReceiptContract": "V14_DETACHED_FINAL_DELIVERY_RECEIPT_CONTRACT_V1.7.85.json",
    "evidenceReadinessPlanner": "V14_EVIDENCE_READINESS_PLANNER_CONTRACT_V1.7.85.json",
    "segmentedAcceptanceManifest": "ACCEPTANCE_SUITE_MANIFEST_V1.7.85.json",
    "segmentedAcceptanceManifestSha256": "5aeddf6644a0ed303f4c80a75d6c603ad5f117044e05cac495f640dad685e4b1",
    "evidenceCollectionPacket": "V14_EVIDENCE_COLLECTION_PACKET_CONTRACT_V1.7.85.json",
    "acceptanceEvidenceBundle": "V14_ACCEPTANCE_EVIDENCE_BUNDLE_CONTRACT_V1.7.85.json",
    "evidenceBatchApplicationAuthorization": "V14_EVIDENCE_BATCH_APPLICATION_AUTHORIZATION_CONTRACT_V1.7.85.json",
    "detachedPublicationManifest": "V14_DETACHED_PUBLICATION_MANIFEST_CONTRACT_V1.7.85.json",
    "evidenceApplicationTransactionPackage": "V14_EVIDENCE_APPLICATION_TRANSACTION_PACKAGE_CONTRACT_V1.7.85.json",
    "detachedReleaseHandoff": "V14_DETACHED_RELEASE_HANDOFF_CONTRACT_V1.7.85.json"
  },
  "finalSource": {
    "state": "FINAL_SOURCE_SEALED_PENDING_FINAL_ARCHIVE_ACCEPTANCE",
    "runs": 2,
    "commandsPerRun": 153,
    "identicalOutput": true,
    "testLogSha256": "d3ae23a30cace8652455cff0a34c5f9464169b07b526c84abae57170459a8333",
    "candidateSha256": "606fc2040beb360760986e4a41b92e8aad09d2331bf18f12af4b9c03be58774f",
    "candidateSizeBytes": 9183739
  }
};

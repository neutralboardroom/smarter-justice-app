(()=>{
  'use strict';
  const path=location.pathname;
  const spanish=path==='/es/'||path.startsWith('/es/');
  const text=(en,es)=>spanish?es:en;

  function setupHeader(){
    const button=document.querySelector('.pre121-menu');
    const nav=document.querySelector('.pre121-header__nav');
    if(!button||!nav)return;
    button.addEventListener('click',()=>{
      const open=button.getAttribute('aria-expanded')==='true';
      button.setAttribute('aria-expanded',String(!open));
      nav.classList.toggle('open',!open);
      nav.dataset.open=String(!open);
    });
  }

  function setupToolChooser(){
    if(path!=='/document-tools.html')return;
    const tools=[...document.querySelectorAll('main section.document-tools-shell')].filter(x=>x.querySelector('form'));
    if(tools.length<2)return;
    const chooser=document.createElement('section');
    chooser.className='pre121-tool-chooser';
    chooser.setAttribute('aria-label','Document tool chooser');
    chooser.innerHTML=`<h2>Choose one task</h2><div class="pre121-tool-chooser__buttons"></div>`;
    const buttons=chooser.querySelector('div');
    tools[0].before(chooser);
    const show=index=>{
      tools.forEach((tool,i)=>tool.hidden=i!==index);
      [...buttons.children].forEach((button,i)=>button.setAttribute('aria-pressed',String(i===index)));
      if(index>0)tools[index].scrollIntoView({behavior:'smooth',block:'start'});
    };
    tools.forEach((tool,index)=>{
      const button=document.createElement('button');
      button.type='button';
      button.textContent=tool.querySelector('h2,h3')?.textContent?.trim()||`Tool ${index+1}`;
      button.addEventListener('click',()=>show(index));
      buttons.append(button);
    });
    show(0);
  }

  function setupResourceDirectory(){
    if(!['/community-resources.html','/es/recursos-comunitarios.html'].includes(path))return;
    const cards=[...document.querySelectorAll('main article.community-need-card')];
    if(cards.length<10)return;
    const first=cards[0];
    const controls=document.createElement('section');
    controls.className='pre121-resource-controls';
    controls.innerHTML=`<h2>${text('Find the kind of help you need','Encuentre el tipo de ayuda que necesita')}</h2><label>${text('Search these resources','Buscar en estos recursos')}<input type="search" autocomplete="off" placeholder="${text('Try housing, food, safety, disability…','Pruebe vivienda, alimentos, seguridad, discapacidad…')}"></label><p aria-live="polite"></p><button type="button"></button>`;
    first.before(controls);
    const input=controls.querySelector('input');
    const status=controls.querySelector('p');
    const more=controls.querySelector('button');
    let expanded=false;
    const render=()=>{
      const q=input.value.trim().toLowerCase();
      let shown=0;
      cards.forEach((card,index)=>{
        const match=!q||card.textContent.toLowerCase().includes(q);
        const visible=match&&(expanded||q||index<9);
        card.hidden=!visible;
        if(visible)shown++;
      });
      status.textContent=text(`${shown} resources shown`,`${shown} recursos mostrados`);
      more.textContent=expanded?text('Show fewer','Mostrar menos'):text('Show all resources','Mostrar todos los recursos');
      more.hidden=Boolean(q);
    };
    input.addEventListener('input',render);
    more.addEventListener('click',()=>{expanded=!expanded;render();});
    render();
  }

  function setupLongPageDisclosure(){
    const rules={
      '/professional-membership.html':4,
      '/pricing.html':3,
      '/attorney-launch.html':2,
      '/professional-growth.html':2,
      '/upload-notice.html':2,
      '/professional-membership-terms.html':2
    };
    const keep=rules[path];
    if(!keep)return;
    const sections=[...document.querySelectorAll('main>section')];
    sections.slice(keep,-1).forEach((section,index)=>{
      if(section.matches('[hidden]')||section.closest('details'))return;
      const heading=section.querySelector('h2,h3');
      if(!heading)return;
      const details=document.createElement('details');
      details.className='pre121-disclosure';
      const summary=document.createElement('summary');
      summary.textContent=heading.textContent.trim();
      const body=document.createElement('div');
      body.className='pre121-disclosure__body';
      section.before(details);
      body.append(section);
      details.append(summary,body);
      if(index===0&&path==='/pricing.html')details.open=true;
    });
  }

  function deferHomepageHelp(){
    if(!['/','/es/','/index.html','/es/index.html'].includes(path))return;
    const reveal=()=>{
      const button=document.querySelector('.live-chat-fallback');
      if(!button)return false;
      button.classList.add('pre121-help-deferred');
      const update=()=>button.classList.toggle('pre121-help-visible',scrollY>360);
      update();
      addEventListener('scroll',update,{passive:true});
      document.querySelector('.pre118-below-fold-cue a')?.addEventListener('click',()=>button.classList.add('pre121-help-visible'));
      return true;
    };
    if(reveal())return;
    const observer=new MutationObserver(()=>{if(reveal())observer.disconnect();});
    observer.observe(document.body,{childList:true});
  }

  function reconcileModuleFlow(){
    if(!path.endsWith('/module.html'))return;
    const apply=()=>{
      const shell=document.querySelector('.pre90-module-shell');
      const callout=document.querySelector('[data-pre96-workbench-callout]');
      if(!shell||!callout)return false;
      const focusedSummary=shell.querySelector('.pre90-module-head p:last-child')?.textContent?.trim();
      const visibleSummary=document.querySelector('.page-hero .lead');
      if(focusedSummary&&visibleSummary)visibleSummary.textContent=focusedSummary;
      callout.classList.add('pre121-module-workbench');
      callout.innerHTML=`<details><summary>${text('Optional Legal Workbench','Mesa legal opcional')}</summary><p>${text('After starting with your situation, you can create an outline, review, compare, and organize information only in this browser.','Después de empezar con su situación, puede crear un esquema, revisar, comparar y organizar información solo en este navegador.')}</p><a class="button-link secondary pre96-inline-action" href="${spanish?'/es/mesa-legal.html':'/legal-workbench.html'}">${text('Open Legal Workbench','Abrir mesa legal')}</a></details>`;
      shell.append(callout);
      return true;
    };
    if(apply())return;
    const observer=new MutationObserver(()=>{if(apply())observer.disconnect();});
    observer.observe(document.body,{childList:true,subtree:true});
    setTimeout(()=>observer.disconnect(),5000);
  }

  document.addEventListener('DOMContentLoaded',()=>{
    setupHeader();
    setupToolChooser();
    setupResourceDirectory();
    setupLongPageDisclosure();
    deferHomepageHelp();
    reconcileModuleFlow();
  });
})();

# Smarter Justice v1.7.98 — Next Version Improvement List

Exact source and rollback baseline: `smarter-justice-v1.7.97-v34-community-network-aligned.zip` — SHA-256 `c307341c99da930fcb8135218f692f9699eed55fb60929aeb312b0fd3ebde4ed`.

Target complete archive: `smarter-justice-v1.7.98.zip`.

1. Publish the exact v1.7.98 source to a reviewed repository branch or pull request and record the exact commit.
2. Store the complete v1.7.98 ZIP durably with SHA-256, size, inventory, tag/release, and retrieval evidence.
3. Configure protected staging for the same exact commit; verify uncached English/Spanish journeys, monitoring, and rollback.
4. Ingest exact V30 `PROFILE_GROWTH_RECEIPT.json` records from every profile-applicable micro-portal and reject token, firms-only, stale, or deficit-hidden growth.
5. Generate a V30 compact continuation only if future full-ZIP transfer becomes genuinely impractical.
6. Continue every preserved P0/P1 item in `NEXT_VERSION_IMPROVEMENT_LIST_V1.7.98.json`.

## Community-centered homepage refresh

- Keep Community Resource Aid prominent throughout the homepage, not limited to one banner.
- Preserve the ten equal legal and tax practice areas as one part of the wider community-access mission.
- Keep one unified Smarter Justice dashboard for attorneys and firms.
- Continue English/Spanish parity and privacy-minimized public starting paths.
- Add measured community-partner sharing and accessibility evidence only after live deployment is verified.

## Community entry experience follow-through

- Measure whether the four public starting paths reduce confusion only after privacy-safe, consented live analytics are approved.
- Keep focused Community Resource Aid links source-transparent and verify official destinations before future releases.
- Add a fully bilingual community-partner handout only after the live-domain pages and print layout are verified.
- Preserve Business Law Aid as an in-development network product without presenting it as one of the ten equal launch areas until its independent launch gates pass.

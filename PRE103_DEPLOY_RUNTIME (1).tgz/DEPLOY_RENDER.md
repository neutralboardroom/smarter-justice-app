# Render deployment — Smarter Justice v1.7.95

Deployment preparation is active and source-qualified. Production is **not deployed or accepted** by this build.

- Exact source and immediate recovery base: `smarter-justice-v1.7.92.zip`, SHA-256 `d3c967220597281d72e27e67d9a55fafccb3ae532508bdba4e66b6d1602078ec`.
- Current candidate target: `smarter-justice-v1.7.98.zip`; immutable final identity remains detached until deterministic packaging and fresh-extraction acceptance complete.
- Qualification target: 165 dependency-independent commands; 166 total readiness parts including separately gated PostgreSQL acceptance.
- V24 role `CENTRAL_MASTER` and workflow `PRODUCT_NEXT_VERSION`, bound to the exact v1.7.91 product artifact and exact V24 packet before source edits.
- Production authorization remains DRAFT and must validate the exact product, repository, environment, version, commit, migration class, gate summary, backup/restore evidence, and rollback target before protected promotion can proceed.
- Payments, AI, uploads, outbound messaging, professional handoffs, email, and analytics remain source-controlled and fail closed in production. Environment variables alone cannot open them; emergency kill switches override all nonproduction access.
- Privacy requests support bilingual intake, private hashed-token status, identity verification, legal/safety hold review, and manual execution receipts. No destructive deletion is automatic.
- Payment reconciliation is preview-only and cannot charge, refund, change subscriptions, or write to Stripe.
- ZIPs are immutable source/evidence/recovery artifacts and must not be deployed directly.
- Auto deploy remains off until exact repository, branch, commit, protected environment, Render service, canonical URL, backup/restore, migration, and owner authorization are verified.
- Render liveness: `/livez`; lane-specific readiness: `/readyz?lane=free-professional-profiles`.
- Never store or paste secret values in source, evidence, logs, screenshots, release artifacts, or chat.

See `deployment/deployment-runbook.md`, `deployment/incident-runbook.md`, `PRODUCTION_AUTHORIZATION_V1.7.90.json`, and `RELEASE_GATE_SUMMARY_V1.7.90.json`.

# PRE75 Roger durable V6 revenue architecture standard

The exact V6 file is mandatory successor authority. It physically preserves V1-V5 and appends the shared-revenue-engine architecture. Future builders must actively use it, preserve the Justice-only vertical boundary, and maintain the three-layer role separation, product/vertical isolation, suppression scope, price authority, Member Care semantics, parity tests, and no-revenue-delay rule.

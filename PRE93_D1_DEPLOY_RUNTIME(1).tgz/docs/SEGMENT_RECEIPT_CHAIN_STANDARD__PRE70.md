# Smarter Justice PRE70 Segment Receipt Chain Standard

## Purpose

PRE70 turns the seven-process inherited-test diagnostic into a durable, independently verifiable receipt chain. The segment runner is evidence producer only. A separate verifier reads the exact manifest, parent receipt, seven persisted child receipt byte streams, and every test row; it then recomputes order, coverage, status, totals, unresolved failures, and acceptance truth.

## Mandatory chain

1. One exact PRE70 test manifest defines seven ordered segments and 166 unique tests.
2. Each isolated segment process writes one atomic child receipt under a run-specific directory.
3. The parent receipt records each child basename, size, SHA-256, segment index, process outcome, and an ordered child-set SHA-256.
4. The parent and every child bind to the same manifest SHA-256 and run ID.
5. The independent verifier derives PASS, FAIL, or TIMEOUT from each row's exit code, signal, timeout evidence, and runner error. A producer-reported PASS is rejected if raw execution fields do not support it.
6. Parent segment objects must be byte-semantically equal to the child segment objects.
7. The exact 166-test order, 160 pass / 6 fail / 0 timeout outcome, and six unresolved failure names must remain truthful until authorized resolution changes them.

## Fail-closed conditions

Missing, corrupt, duplicated, reordered, truncated, hash-mismatched, wrong-run, wrong-index, or semantically inconsistent receipts fail verification. Any suite-pass or release-acceptance overclaim fails verification. Known failures are never an acceptance allowlist.

## Scope boundary

PRE70 provides local SHA-256-bound semantic verification. It does not claim a digital signature, signer identity, trusted timestamp, GitHub artifact attestation, SLSA conformance, production execution, or deployment acceptance. Signed remote attestations remain deferred until an authorized GitHub workflow and exact commit are available.

## Protected surfaces

The PRE64 attorney tour, professional-responsibility page, canonical stylesheet, and restored professional-membership page remain hash-protected. PRE70 changes no public interface merely to make inherited review-dependent tests pass.

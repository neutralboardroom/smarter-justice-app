# Smarter Justice PRE66 Fast Verified Build Standard

## Durable ordinary build path

Every ordinary next-version build must start from a canonical predecessor runtime carrier whose archive size, SHA-256, safe member paths, file count, canonical tree SHA-256, release markers, and protected-surface hashes are verified before the current overlay runs.

The default build must not replay every historical overlay. The full historical replay remains available through `npm run rebuild:full-history` as an explicit audit path. Removing or silently weakening that audit path fails the release.

## Bounded external operations

Local source qualification skips nested runtime dependency installation unless `SJ_RUNTIME_INSTALL_MODE=required` is explicitly selected. CI and Render resolve `auto` to required. The install subprocess has a bounded timeout and failures are receipted.

Browser capability checking is separate from the ordinary build. It uses a five-second subprocess bound. Missing browser support, timeout, or process failure is recorded as unavailable and never represented as visual acceptance.

## Three deliverables

Every version must still deliver all three roles together: Product source ZIP, Evidence & receipts ZIP, and Builder & continuation ZIP. A one- or two-file handoff is incomplete and fails closed.

# Smarter Justice PRE68 Semantic Funnel and Segmented-Test Standard

PRE68 replaces fragile homepage copy matching with stable checks of meaning, destinations, and implementation boundaries. The contract requires a problem-first public entry, a distinct professional route, sensitive-detail warnings, a working story route, a server response that explicitly reports `saved:false`, no persistence call in that handler, dynamic professional-program status, and truthful closed-payment state. Accepted marketing wording may change without breaking the gate when those substantive conditions remain true.

The complete inherited 166-command suite remains unchanged as `npm test` and `npm run test:aggregate:audit` for historical audit. PRE68 adds seven bounded segments and a runner that executes each test in a separate Node process, captures a receipt, continues after failures, and applies per-test and global timeouts. Gate mode fails on any failed or timed-out test. Diagnostic mode exists only to reveal all blockers in one run; it never treats a failure as a pass or claims release acceptance.

Static exact-source browser evidence, CI live-route evidence, and post-deployment acceptance remain distinct. No segment or browser artifact may contain user, matter, credential, secret, or private operational data.

## Authoritative page-restoration boundary

When a canonical runtime carrier member is structurally incomplete but the exact predecessor Product Source contains the complete accepted page, the build may restore only the exact predecessor source bytes after recording both hashes, sizes, missing structural tokens, and the restoration method. It may not invent replacement copy, silently normalize the defect, or represent the carrier member as authoritative over the sealed Product Source. The restored route must be added to rendered evidence at both required viewports.


# Smarter Justice Three-Deliverable Release Standard — PRE65

**Durable rule:** every new Smarter Justice version must deliver exactly three required ZIP artifacts together:

1. **Product source ZIP** — the preservable source/bootstrap artifact for the new version.
2. **Evidence & receipts ZIP** — qualification, research, visual/integrity evidence, limitations, and receipts.
3. **Builder & continuation ZIP** — current continuation authority, next-version list, durable rules, and executable/checkable builder files.

A one- or two-file handoff is incomplete and fails closed. No role may silently substitute for another. After immutable packaging, the final handoff must state the basename, byte size, and SHA-256 for all three. The evidence archive cannot self-contain its own final digest without creating a hash cycle, so the final three digests are detached handoff facts computed after all three ZIPs are immutable.

This rule applies to review-ready candidates as well as promotable releases. It does not authorize merge or deployment and does not weaken any legal/ethics, privacy, accessibility, visual, owner-acceptance, exact-commit, or deployment gate. It remains binding until Roger explicitly supersedes it with an equally explicit Smarter Justice product-scoped rule.

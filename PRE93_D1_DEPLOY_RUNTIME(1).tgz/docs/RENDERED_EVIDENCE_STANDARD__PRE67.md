# Smarter Justice Rendered-Evidence Standard — PRE67

## Durable rule

Every material Smarter Justice version must produce evidence from representative public and professional routes at a phone and desktop viewport before production acceptance. The evidence must test actual layout, route hierarchy, navigation, forms, calls to action, trust language, and basic accessibility-oriented structure. A source-only assertion, browser-binary probe, or screenshot-free claim is not rendered acceptance.

## Two evidence tiers

### 1. Static exact-source browser evidence

This tier exists for controlled environments where browser URL navigation is blocked by managed policy. It loads the exact candidate HTML, inlines candidate-local CSS and images, removes application scripts, blocks network requests, and renders the result in Chromium. It can prove that the candidate source bytes produce a reviewable responsive visual result. It cannot prove server routing, JavaScript behavior, API behavior, deployment, post-deployment operation, or accessibility conformance.

### 2. CI live-route browser gate

This tier starts the candidate application and navigates the representative route matrix inside a version-matched Playwright browser image. It is sequential and bounded. It records full-page screenshots, route status, document structure, accessible names, form labels, duplicate IDs, horizontal overflow, and route-specific funnel selectors. It is candidate CI evidence only; production acceptance still requires post-deployment route and screenshot verification.

## Evidence minimization

Only static public and professional pages may be captured. Do not place user, matter, credential, payment, or private operational data in screenshots or receipts. Traces and video remain disabled by default because they can retain more page and network detail than the release needs. The CI artifact is retained for 14 days unless a qualified investigation requires a separately approved period.

## Fail-closed boundaries

A browser launch, navigation, render, screenshot, protected-surface hash, or required-selector failure blocks the corresponding gate. Static evidence may never be renamed as live evidence. CI evidence may never be renamed as production evidence. Automated checks do not establish WCAG conformance, legal compliance, privacy acceptance, or qualified human review.

## No-change decisions

A release may preserve the interface when the actual rendered matrix shows no material regression or evidence-backed reason for alteration. No-change decisions must identify the reviewed routes, viewports, automatic findings, manual observations, and remaining acceptance limits.

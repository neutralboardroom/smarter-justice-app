# Roger Durable Revenue Authority — PRE72

PRE72 binds the exact August 15, 2026 V2 Roger durable revenue/acquisition authority into Smarter Justice. New enrollment pricing is Professional $12/$120, Team $29/$290 (up to 5), Office $49/$490 (default up to 15), Enterprise/Network custom. Annual standard plans equal ten monthly payments. Existing legacy founding subscriptions are preserved as grandfathered-only rather than silently repriced. Payment never buys verification, ranking, endorsement, or guaranteed legal matters.

Every successor must preserve the exact authority file and SHA-256, recheck current law/market/deliverability/payment facts, maintain the required acquisition outputs, attack the highest safe P0 revenue blocker, and preserve live-action gates. This layer does not itself authorize live billing, outreach, GitHub promotion, or Render deployment.

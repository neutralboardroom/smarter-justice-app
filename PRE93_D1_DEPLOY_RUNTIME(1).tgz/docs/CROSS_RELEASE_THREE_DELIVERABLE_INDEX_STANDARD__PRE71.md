# Cross-Release Three-Deliverable Index Standard — PRE71

PRE71 keeps a compact metadata-only index for PRE65 through PRE70. Each release must have exactly Product Source, Evidence & Receipts, and Builder & Continuation identities in fixed order. The index binds canonical basename, byte size, SHA-256, ZIP-integrity result, member count, and uncompressed byte count without embedding any prior large archive.

The index fails closed on missing releases or roles, duplicate roles or artifact hashes, invalid sizes or digests, reordered coverage, digest mismatch, or any claim that redundant archives are embedded. Local SHA-256 verification is not a digital signature, remote attestation, trusted timestamp, SLSA claim, or production acceptance.

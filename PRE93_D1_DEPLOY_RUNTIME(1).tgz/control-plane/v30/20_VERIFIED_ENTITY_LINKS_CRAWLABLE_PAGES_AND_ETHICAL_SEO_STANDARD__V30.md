# VERIFIED ENTITY LINKS, CRAWLABLE PAGES, AND ETHICAL SEO STANDARD — V30

**Packet ID:** `SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V30-INDIVIDUAL-FIRST-PROFILE-GROWTH`  
**Owner:** Roger Gillman  
**Effective:** 2026-08-05T13:46:00-04:00

This standard applies to Smarter Justice and every approved micro-portal in every ordinary material build.

## 1. Verified official outbound links
When a published profile, organization, agency, court, program, nonprofit, firm, professional association, accredited representative, educational resource, or other material entity has a trustworthy official website or authoritative official page, provide a descriptive crawlable HTML link using an `<a href="...">` element. The link must help the visitor verify the entity or reach a useful official resource. Do not use vague anchor text such as “click here” when a concise descriptive name is available.

Ordinary verified editorial links do not need `nofollow`. Use `rel="sponsored"` for paid placements, `rel="ugc"` for untrusted user-supplied links, and `rel="nofollow"` when the destination is not trusted or the relationship otherwise requires qualification. When opening a link in a new tab, use the appropriate browser security protection such as `rel="noopener"`.

## 2. Dedicated crawlable entity pages
A substantial organization, agency, firm, program, or professional profile should receive its own stable, indexable URL when the page provides real user value. Use descriptive paths appropriate to the portal, for example:

- `/organizations/{slug}/`
- `/agencies/{slug}/`
- `/programs/{slug}/`
- `/firms/{slug}/`
- `/professionals/{slug}/`

Do not rely on `#fragment` routes to represent separate pages or load materially different entity content. Every important page must be reachable through crawlable internal `<a href>` links and included in an appropriate sitemap or equivalent discovery mechanism.

## 3. People-first bilingual page quality
Each dedicated entity page must contain original, useful, portal-specific English and Spanish content rather than copied boilerplate or search-engine filler. As applicable, include:

- accurate entity name and type;
- official website or authoritative source link;
- service area and eligibility or audience information;
- relevant specialties or services without unsupported claims;
- source and recheck dates;
- neutral unclaimed/claimed status where relevant;
- correction, removal, suppression, or update path;
- clear non-endorsement and availability disclaimers;
- related portal topics, tools, checklists, and internal links;
- accessible headings, metadata, breadcrumbs, and mobile presentation.

Do not create thin, duplicate, doorway, location-spam, keyword-stuffed, mass-translated, scraped, or scaled pages whose primary purpose is manipulating rankings. A page that cannot add distinct user value must remain unpublished or `noindex` until it meets the quality floor.

## 4. Technical discoverability
For every material entity page and directory:

- return a truthful HTTP status, normally `200` for a live page;
- provide a stable canonical URL;
- ensure the main content is indexable and visible to users;
- use crawlable internal and external links;
- update sitemaps and internal navigation where appropriate;
- avoid fragment-only routing for separate content;
- validate structured data only when it accurately represents the page and entity;
- avoid duplicate canonicals, orphan pages, accidental `noindex`, robots blocks, and JavaScript-only content that cannot be reliably discovered;
- test rendered HTML and uncached live behavior.

## 5. Link and destination safety
Every material build must audit existing and newly added links for destination identity, HTTPS availability where supported, redirect chains, broken responses, domain changes, ownership changes, malware or phishing risk, misleading redirects, stale programs, and inappropriate destinations. Repair, replace, qualify, suppress, or remove unsafe and obsolete links. Preserve source dates and the date of the last recheck.

## 6. Ethical growth and backlink earning
External links are for user verification, useful context, and source transparency—not a ranking shortcut. The strongest legitimate backlink opportunity comes from producing genuinely useful pages and tools that organizations independently choose to cite. Lawful outreach may inform an entity that a useful, accurate page exists and invite corrections, but must never promise rankings, demand reciprocal links, buy editorial links, disguise sponsorship, or create link schemes.

## 7. Structured data boundaries
Use structured data only when it is supported by visible page content and the current product evidence. Do not falsely mark third-party entities as the portal’s own organization, imply endorsement, claim unavailable services, fabricate reviews, or use `sameAs` to merge unrelated identities. Validate JSON-LD and preserve the distinction between the portal, listed entities, professionals, firms, agencies, and programs.

## 8. Required release evidence
Every material release must record:

- official links added, refreshed, rejected, qualified, or removed;
- dedicated entity pages added, refreshed, rejected, or left `noindex`;
- English and Spanish entity-page counts and audit results;
- crawlable internal-link, sitemap, canonical, status-code, rendered-content, and structured-data checks;
- broken-link, redirect, domain-ownership, malware/phishing, and stale-destination findings;
- paid, user-generated, and untrusted link qualification results;
- confirmation that no reciprocal-link scheme, ranking guarantee, doorway abuse, or scaled-content abuse was used;
- resulting implementation decisions and Next Version Improvement List entries.

External links and entity pages must improve user trust and discoverability without compromising neutrality, safety, simplicity, or page quality.

## V30 transfer continuity
Packaging mode must never narrow the improvement pass, profile work, current research, bilingual audit, verified-link/entity-page work, qualification, live-readiness, or evidence. Compact-pointer products must retrieve exact full source before implementation, and every successful release must preserve a complete full artifact plus the correct successor continuation package.

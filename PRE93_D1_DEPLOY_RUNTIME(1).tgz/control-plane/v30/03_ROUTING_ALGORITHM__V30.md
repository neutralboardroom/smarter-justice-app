# V30 ROUTING ALGORITHM

1. Identify the universal packet by exact packet ID `SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V30-INDIVIDUAL-FIRST-PROFILE-GROWTH` and verify its checksums and owner-rule lock.
2. Inspect every other uploaded artifact without executing it.
3. Determine Upload 1 artifact mode:
   - complete product source → `FULL_PRODUCT_ZIP`;
   - compact identity/evidence package with no application source → `COMPACT_POINTER`;
   - cumulative current source with declared exclusions → `CUMULATIVE_LEAN_SOURCE`;
   - approved greenfield identity → `APPROVED_SEED`.
4. For compact modes, validate the compact-package manifest, release identity, SHA256SUMS, owner-rule binding, and inclusion/exclusion claims. A changed-files list never proves source completeness.
5. Identify exactly one product using internal manifests first, then exact repository/domain/version/root/filename evidence. Do not route from vague chat memory.
6. Select exactly one role and workflow. Smarter Justice central evidence routes to `CENTRAL_MASTER`; one identified portal routes to `PRODUCT_WORKER`; greenfield, recovery, incident, status, or packet-refinement modes require their explicit conditions.
7. Emit the required builder-selection declaration including artifact mode, exact input identities, authoritative full-source location, source-retrieval status, clean-deployment status, owner-rule chain, confidence, and ambiguities.
8. If `COMPACT_POINTER`, retrieve and verify the exact connected full source before modifying code. Verify repository, source commit, main commit when known, tag/release, full artifact hash/size, manifests, CI, and deployment evidence.
9. Fail closed only when exact identity, full-source retrieval, owner-rule chain, safety, or owner-controlled access cannot be established. Ask for one unavoidable owner action only.
10. Begin the selected command immediately. Preserve all OR-001 through OR-111 requirements, including profiles, current research, verified links, useful crawlable bilingual pages, language audits, early safe live deployment, data continuity, full release archival, and successor continuation packaging.

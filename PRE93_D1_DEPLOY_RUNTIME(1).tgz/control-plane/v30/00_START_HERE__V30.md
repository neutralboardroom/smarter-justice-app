# START HERE — V30 COMPLETE, COMPACT, SELF-ROUTING UNIVERSAL MASTER PACKET

**Packet ID:** `SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V30-INDIVIDUAL-FIRST-PROFILE-GROWTH`  
**Owner:** Roger Gillman  
**Effective:** 2026-08-05T16:28:00-04:00

This is the single universal master ZIP used with the newest exact product artifact. It supersedes V29. Everything required for routing, building, current research, substantial individual-professional profile growth, verified entity links, bilingual language review, qualification, release, deployment, recovery, compact continuation, schemas, templates, validation, and durable owner-rule continuity is inside this ZIP.

## Normal use: exactly two uploads

1. Upload the newest product artifact in one declared mode: `FULL_PRODUCT_ZIP`, `COMPACT_POINTER`, `CUMULATIVE_LEAN_SOURCE`, or approved greenfield `APPROVED_SEED`.
2. Upload this V30 universal master ZIP.

Use the complete exact latest product ZIP whenever practical. When size or repeated transfer failure makes that impractical, use a compact continuation that binds the exact full source and retrieve that source from the connected authoritative repository. Never use a tiny ambiguous patch and never clean-deploy a compact pointer.

## Mandatory reading order

1. `02_ROUTING_MANIFEST__V30.json`
2. `03_ROUTING_ALGORITHM__V30.md`
3. `04_REQUIRED_BUILDER_SELECTION_DECLARATION__V30.md`
4. `13_PERMANENT_OWNER_RULES_REGISTER__V30.json`
5. `16_DURABLE_OWNER_RULES_LOCK__V30.json`
6. `18_CONTINUOUS_IMPROVEMENT_RESEARCH_PROFILE_LIVE_AND_LANGUAGE_STANDARD__V30.md`
7. `19_VALUE_RISK_RESEARCH_PROFILE_AND_RELEASE_DISCIPLINE__V30.md`
8. `20_VERIFIED_ENTITY_LINKS_CRAWLABLE_PAGES_AND_ETHICAL_SEO_STANDARD__V30.md`
9. `21_LARGE_PRODUCT_COMPACT_CONTINUATION_AND_FULL_SOURCE_STANDARD__V30.md`
10. `24_INDIVIDUAL_FIRST_PROFESSIONAL_PROFILE_GROWTH_STANDARD__V30.md`
11. The selected role command and applicable workflow supplement.

## Material V30 improvements

- Preserves all 111 V29 durable owner rules exactly and adds ten compatible profile-growth rules, OR-112 through OR-121.
- Makes net-new accepted individual professionals the primary profile-growth workstream; firms and organizations no longer substitute for individuals.
- Sets a default target of 25 and an ordinary completion floor of 12 net-new accepted individuals for profile-applicable builds, with narrow evidence-based exceptions and durable deficit carry-forward.
- Requires one canonical useful crawlable bilingual page for every accepted individual, verified individual-firm relationships, broad source coverage, and publication-ready counting only.
- Requires exact compact handoff counts for new individuals, firms or organizations, new professional-firm links, refreshes, rejections, final totals, targets, floors, and deficits.
- Rejects token additions and requires scalable ingestion, deduplication, recheck, enrichment, bilingual publication, correction, suppression, and withdrawal tooling.
- Preserves all V29 compact continuation, complete full-artifact, research, innovation, verified-link, ethical-SEO, early-live, English/Spanish, safety, data-continuity, and no-drift requirements.

## Role routing

- Smarter Justice central portfolio work → `CENTRAL_MASTER` → `05_CENTRAL_MASTER_AUTOSTART_COMMAND__V30.txt`.
- One exact non-Smarter-Justice product → `PRODUCT_WORKER` → `06_PRODUCT_WORKER_AUTOSTART_COMMAND__V30.txt`.
- Approved greenfield product → also read `07_GREENFIELD_AUTOSTART_COMMAND__V30.txt`.
- Existing live product upgrade → also read `08_EXISTING_LIVE_PRODUCT_UPGRADE_COMMAND__V30.txt`.
- Recovery or deployment continuation → also read `09_RECOVERY_AND_DEPLOYMENT_AUTOSTART_COMMAND__V30.txt`.
- Live incident → `10_INCIDENT_RESPONSE_AUTOSTART_COMMAND__V30.txt`.
- Status only → `11_STATUS_ONLY_COMMAND__V30.txt`.
- Universal-packet refinement → `12_PACKET_REFINEMENT_COMMAND__V30.txt`.

## Fail closed correctly

Stop only for unreadable or unsafe artifacts, conflicting identities, multiple plausible products, missing exact full source, failed owner-rule chain, unavailable authoritative repository for a compact pointer, unauthorized rule drift, or a genuinely owner-controlled dependency. Do not use profile research, compact packaging, broad research, or one blocked capability as an excuse to avoid safe independent work.

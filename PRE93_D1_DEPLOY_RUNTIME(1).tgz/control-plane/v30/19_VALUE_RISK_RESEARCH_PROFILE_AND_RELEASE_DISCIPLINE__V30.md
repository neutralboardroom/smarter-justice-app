# VALUE, RISK, RESEARCH, PROFILE, AND RELEASE DISCIPLINE — V30

## 1. Decision order
Protect users and data; preserve working live capability; satisfy durable owner rules; deliver the highest verified user and professional value; maintain simplicity; then optimize speed and breadth.

## 2. Release-scope test
A proposed change belongs in the current release when it has supported value, compatible dependencies, complete English/Spanish behavior, testable acceptance criteria, operational support, observability, and a safe migration or rollback path. Unrelated high-risk changes should be separated when that lowers combined failure risk. This is not a one-change rule.

## 3. Research quality test
For each material source, record who published it, when it was accessed, whether the information is current, why it is relevant, what conflicts exist, and what product decision follows. Use official or primary sources for legal, regulatory, eligibility, status, deadline, provider, and other unstable facts whenever available.

## 4. Profile publication test
Before publication, claim invitation, outreach, featuring, or opportunity distribution, confirm deduplication, identity, status, specialty relevance, source freshness, contact evidence, portal acceptance, neutral presentation, correction path, suppression path, and date of recheck.

## 5. Innovation test
Score each material proposal for user need, professional value, simplicity, accessibility, bilingual completeness, privacy, security, legal safeguards, maintainability, support burden, operating cost, and measurable acceptance. Implement, defer, or reject with evidence.

## 6. Live-learning test
Use uncached desktop/mobile journeys, support findings, accessibility and reliability evidence, consented feedback, and privacy-minimized aggregate signals. Do not use sensitive legal facts, documents, messages, or unnecessary identifiers for analytics. Record the decision changed by the evidence.

## 7. Rule-chain test
Every work order and release record must carry the V30 packet ID, canonical rule hash, rule count, and PASS/BLOCKED validation result. No product may be qualified or promoted when the chain is missing or mismatched.

## 8. Deferred-value continuity
Every deferred high-value item must include title, value, evidence, priority, dependencies, risk, and acceptance criteria. The next material build must review unresolved items and record implementation, continued deferral, or rejection with reason.


## 9. Entity-link value and safety test
Add an outbound link only when the destination is official or otherwise trustworthy, relevant, useful to the visitor, and current. Use descriptive anchor text and appropriate rel qualification. Reject unsafe, stale, misleading, paid-but-undisclosed, user-generated-but-unqualified, or SEO-only links.

## 10. Dedicated entity-page publication test
Publish a dedicated page only when it has a stable URL, distinct bilingual user value, verified identity and sources, original specialty-relevant content, internal links, correction paths, truthful metadata, technical discoverability, and a quality floor high enough to avoid thin, duplicate, doorway, or scaled-content abuse.

## 11. Technical discoverability test
Verify truthful HTTP status, canonical, sitemap or equivalent discovery, crawlable `<a href>` links, non-fragment routing for separate content, visible indexable content, rendered HTML, accessible navigation, and accurate structured data. Record any intentional noindex decision.

## 12. Ethical SEO test
Never guarantee rankings or use paid-link schemes, reciprocal-link demands, hidden sponsorship, doorway pages, keyword stuffing, mass-generated low-value pages, or misleading structured data. Favor useful content, transparent sources, accurate entity pages, and independent editorial backlinks earned through value.

## V30 transfer continuity
Packaging mode must never narrow the improvement pass, profile work, current research, bilingual audit, verified-link/entity-page work, qualification, live-readiness, or evidence. Compact-pointer products must retrieve exact full source before implementation, and every successful release must preserve a complete full artifact plus the correct successor continuation package.

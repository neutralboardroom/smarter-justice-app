# CONTINUOUS IMPROVEMENT, RESEARCH, PROFILE, EARLY-LIVE, AND LANGUAGE STANDARD — V30

This standard applies to every material Smarter Justice and portal build.

## A. Comprehensive review and selective high-value implementation
Review public and authenticated UX, homepage, navigation, tools, content, official resources, AI, storage, payments, profiles, professional onboarding, referrals, discovery, accessibility, security, privacy, performance, reliability, email, support, monitoring, backup, recovery, deployment, English, Spanish, and business value. Implement multiple compatible high-value improvements, not cosmetic churn.

## B. Risk-bounded release units
A comprehensive review does not require every idea to enter one release. Group compatible changes into testable and rollback-safe units. Define dependencies, data impact, bilingual acceptance, observability, and rollback. Separate unrelated high-risk changes when doing so materially improves safety.

## C. Proactive innovation
Independently identify specialty-specific calculators, organizers, checklists, evidence tools, document helpers, explainers, comparison tools, readiness tools, dashboards, saved-work flows, professional tools, referrals, trust features, accessibility improvements, and operational automation. Evaluate value, simplicity, bilingual completeness, safety, maintenance, and cost before implementation.

## D. High-quality profiles
Find verified individual professionals and relevant firms or organizations. Dedupe and recheck identity, current status, accreditation or registration where applicable, specialty evidence, source freshness, contact evidence, and publication eligibility. Separate candidate, accepted, published, claimed, corrected, suppressed, and withdrawn states. No filler or fabrication.

## E. Current actionable research
Research official government and court sources, agencies, regulators, public programs, legal aid, nonprofits, advocacy/community groups, professional organizations, educational resources, directories, firms, legacy publishers/marketplaces, established competitors, AI legal startups, adjacent AI/consumer technology, and other relevant entities. Record source, date, freshness, finding, conflict, and product implication. Prefer official or primary sources for unstable facts. Research must lead to implementation, supported rejection, or a prioritized future item.

## F. Early live operation and privacy-safe learning
Build for production from the start. Launch a safe, useful, honest bilingual public version when minimum gates pass and keep unverified sensitive features closed. Use protected staging and exact production promotion. Audit the uncached live product on desktop and mobile. Use support findings, consented feedback, reliability and accessibility evidence, and privacy-minimized aggregate signals; never collect sensitive legal information merely for analytics.

## G. English/Spanish language audit
Audit every visible and assistive text surface in both languages. Check accuracy, plain language, tone, legal caution, audience fit, translation quality, terminology consistency, instructions, errors, internal/developer wording, jargon, metadata, emails, AI outputs, professional messages, and mobile truncation. Preserve simplicity without hiding valuable depth.

## H. Cross-portal learning without homogenization
Reuse versioned platform components, tests, security, accessibility, deployment, and research methods where they improve quality. Adapt them to the specialty, audience, brand, jurisdictional limits, workflows, and maturity. Never cross product profiles, user data, credentials, services, authorizations, claims, or evidence.

## I. Verified entity links and crawlable page growth
Add or refresh verified official outbound links and create stable dedicated entity pages when they add distinct bilingual user value. Use descriptive crawlable anchors, clean URLs, internal links, sitemaps, canonicals, rendered-content checks, accurate structured data, link safety audits, and ethical rel qualification. Reject thin, duplicate, doorway, scaled, scraped, or manipulative pages. Preserve homepage simplicity through directories, search, filters, and progressive disclosure.

## J. Required evidence
Complete `TEMPLATES/COMPREHENSIVE_BUILD_IMPROVEMENT_RECEIPT.template.json` and validate it against `SCHEMAS/comprehensive-build-improvement-receipt.schema.json`. Bind it to the exact product, artifact, V30 packet ID, owner-rule hash, release-risk plan, research freshness, profile quality, innovation decisions, language audit, live learning, deployment state, and structured next-version list.

## V30 transfer continuity
Packaging mode must never narrow the improvement pass, profile work, current research, bilingual audit, verified-link/entity-page work, qualification, live-readiness, or evidence. Compact-pointer products must retrieve exact full source before implementation, and every successful release must preserve a complete full artifact plus the correct successor continuation package.

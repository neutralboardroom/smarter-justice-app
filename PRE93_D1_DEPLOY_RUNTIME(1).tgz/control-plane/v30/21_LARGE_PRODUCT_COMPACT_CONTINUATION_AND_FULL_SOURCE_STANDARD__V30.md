# LARGE-PRODUCT COMPACT CONTINUATION AND FULL-SOURCE STANDARD — V30

**Packet ID:** `SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V30-INDIVIDUAL-FIRST-PROFILE-GROWTH`  
**Owner:** Roger Gillman  
**Effective:** 2026-08-05T13:46:00-04:00

This standard applies to Smarter Justice, Immigration Oasis, every legal micro-portal, and every product routed by this universal packet.

## 1. Preferred and permitted Upload 1 modes

The normal two-upload system remains:

1. Upload 1: the product artifact.
2. Upload 2: this universal master ZIP.

Upload 1 must declare exactly one mode:

- `FULL_PRODUCT_ZIP` — preferred whenever the complete newest exact product ZIP transfers successfully.
- `COMPACT_POINTER` — a small exact continuation package containing identity, source, release, CI, deployment, and owner-rule evidence but no application source. This is permitted only when the connected authoritative repository and exact release evidence can supply the complete source.
- `CUMULATIVE_LEAN_SOURCE` — a complete current continuation source package excluding only specifically declared heavy or externally managed assets. It is never a changed-files patch.
- `APPROVED_SEED` — only for an approved greenfield product with an exact identity record.

The builder must not choose a compact mode merely because it is easier. Record the actual transfer problem or size constraint.

## 2. Required compact-pointer contents

A `COMPACT_POINTER` must contain at least:

- `00_START_HERE...` with next-chat instructions;
- `CONTINUATION.md`;
- `release-identity.json`;
- a machine-readable compact-package manifest;
- release-verification summary;
- changed-files summary;
- Next Version Improvement List;
- universal packet and owner-rule binding;
- `SHA256SUMS.txt`.

The identity record must bind product, repository, version, source commit, merged-main commit when known, base ref, tag or release, production URL where applicable, full-artifact hash and size, CI/release evidence, packet ID, owner-rule hash, owner-rule count, and continuation policy.

## 3. Required cumulative-lean contents

A `CUMULATIVE_LEAN_SOURCE` must contain the complete current source required for the next build except declared exclusions. Include source, tests, package manifests, lockfiles, migrations, schemas, documentation, deployment configuration, release evidence, and a complete inclusion/exclusion inventory. Do not require earlier lean ZIPs to reconstruct the current source.

Permissible exclusions may include large static media, generated dependencies, caches, compiled output, test recordings, or durable externally managed assets when their exact location, integrity, retrieval, and protection are documented. Never omit critical source, lockfiles, migrations, tests, or deployment controls to make the package smaller.

## 4. Full artifact remains mandatory

Every material release must still create or preserve a complete exact full artifact in the authoritative repository, GitHub release, CI artifact store, protected object storage, or other approved durable system. Record the hash, size, inventory, provenance, commit, tag, and retrieval path. Compact transfer changes what Roger uploads to the next chat; it does not turn the compact package into the complete release.

## 5. Retrieval and verification before work

For `COMPACT_POINTER`, retrieve the bound connected private repository and verify:

- exact repository and product;
- source commit and merged-main commit when known;
- tag or release;
- full artifact hash and size;
- package/release manifests;
- CI and qualification evidence;
- open pull requests and current main state;
- staging, production, and rollback evidence where relevant.

Do not change code until these identities agree. Work on an isolated branch and preserve protected deployment authorization.

## 6. Deployment boundary

Never clean-deploy a compact pointer. Do not treat a lean package as deployment-complete unless its manifest explicitly says so and full qualification proves it. Deploy the exact qualified full source commit or complete full release artifact through the normal auditable GitHub/Render or product-specific pipeline.

## 7. Data and asset continuity

The absence of a database, upload, private document, payment record, managed store, environment secret, or heavy asset from a transfer package never authorizes deletion. Preserve live data, tenant isolation, storage references, migrations, backups, restore evidence, secrets, and rollback continuity.

## 8. Successor package

After every successful material release of a compact-mode product, produce a successor compact continuation package with the new exact identity and evidence. A changed-files list is useful context but is never the authoritative source. Nothing necessary may exist only in chat.

## 9. Owner-facing truth

Whenever practical, return the complete newest exact product ZIP. When compact transfer is required, say plainly that the owner is receiving a compact continuation, identify the complete full artifact’s durable location and exact hash, and state that the compact package must not be clean-deployed.

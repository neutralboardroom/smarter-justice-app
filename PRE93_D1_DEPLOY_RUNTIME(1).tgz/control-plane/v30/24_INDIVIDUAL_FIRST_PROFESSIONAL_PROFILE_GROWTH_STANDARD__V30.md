# V30 INDIVIDUAL-FIRST PROFESSIONAL PROFILE GROWTH STANDARD

**Authority:** OR-017, OR-077, OR-087, OR-092, OR-093 through OR-100, and OR-112 through OR-121.

## 1. Purpose

Every ordinary profile-applicable legal micro-portal build must add a meaningful batch of verified individual professionals, not merely a few firms or organizations. Quantity and quality are simultaneous requirements. Quality may not be weakened to hit a number, and quality review may not be used to justify token additions when a substantial verified source pool exists.

## 2. Applicability

Mark profile growth `APPLICABLE` for a legal portal that publishes, searches, recommends, claims, onboards, or manages professionals, firms, accredited representatives, or organizations. `NOT_APPLICABLE` requires a product-specific explanation and central-master evidence; it may not be used as a generic escape. Emergency, hotfix, recovery, and rollback-only releases may defer the batch but must carry the exact deficit forward.

## 3. Numeric standard

- Default target: at least **25 net-new accepted individual professionals** in each ordinary applicable build.
- Ordinary completion floor: at least **12 net-new accepted individual professionals**.
- Firms and organizations are tracked separately and do not substitute for individuals.
- Any shortfall becomes a durable profile-growth deficit added to the next ordinary target.
- Under-target completion requires a dated exhaustive source log, candidate dispositions, exact blocker or sparse-pool explanation, and deficit carry-forward.

## 4. Source funnel

Use multiple relevant source categories, led by official or primary evidence: licensing and registration datasets; individual official directories; accreditation databases; courts, agencies, and government programs; bar and professional associations; firm rosters; legal-aid and nonprofit rosters; accredited-organization directories; professional websites; and reputable directories used only as leads requiring verification. For New York attorneys, use authoritative OCA registration data and a current individual directory recheck when applicable.

Research should reach beyond only famous firms: solo and small practices, midsize and large firms, public-interest and legal-aid professionals, specialty organizations, relevant geographic areas, and useful language/service capabilities. Do not target or infer protected traits, fabricate diversity, or use pay-to-play inclusion.

## 5. Candidate lifecycle

Use explicit states: `DISCOVERED`, `IDENTITY_MATCHED`, `SOURCE_VERIFIED`, `SPECIALTY_SUPPORTED`, `RELATIONSHIP_VERIFIED`, `BILINGUAL_PAGE_READY`, `ACCEPTED`, `REJECTED`, `DUPLICATE`, `STALE`, `UNRESOLVED`, `SUPPRESSED`, or `WITHDRAWN`. Only `ACCEPTED` publication-ready individuals count as net-new growth.

## 6. Canonical individual page

Each accepted individual receives one stable crawlable canonical URL, original useful English and Spanish content, exact role/status, jurisdiction or service area, specialty evidence, verified affiliation, official links where available, source/recheck dates, neutral non-endorsement language, claim/correction/suppression/removal controls, and internal links to related firms, organizations, topics, and tools. Reject thin, duplicated, copied, doorway, keyword-stuffed, or mass-generated pages.

## 7. Relationship links

Create or refresh verified individual-to-firm or individual-to-organization relationships. Require current source evidence. Never infer a relationship from a shared address, telephone number, email domain, or third-party directory appearance alone. Count new verified relationships separately from profiles.

## 8. Scalable implementation

Maintain deterministic reusable ingestion, normalization, identity matching, deduplication, source dating, status recheck, specialty-evidence, relationship, bilingual page, validation, publication, correction, suppression, withdrawal, and audit tooling. Automate repetitive safe transformations and tests; retain qualified review for sensitive claims. Manual one-off editing is not an acceptable long-term bottleneck.

## 9. Required release evidence

Produce `PROFILE_GROWTH_RECEIPT.json` conforming to `SCHEMAS/profile-growth-receipt.schema.json`, plus a human-readable compact handoff reporting:

- target and ordinary floor;
- prior and remaining deficit;
- new accepted individuals;
- new firms or organizations;
- new verified individual-firm/organization links;
- refreshed individuals and firms/organizations;
- rejected, duplicate, stale, unsupported, and unresolved candidates;
- final individual and firm/organization totals;
- source categories and recheck method;
- exact exception evidence, when applicable.

Missing counts, firms-only growth, candidate inflation, hidden deficits, or token additions are incomplete evidence.

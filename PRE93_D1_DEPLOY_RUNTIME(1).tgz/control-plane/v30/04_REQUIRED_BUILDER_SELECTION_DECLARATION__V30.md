# REQUIRED V30 BUILDER-SELECTION DECLARATION

Before substantive work, emit and retain a declaration with:

```json
{
  "schemaVersion": 3,
  "selectedRole": "CENTRAL_MASTER | PRODUCT_WORKER | GREENFIELD_WORKER | RECOVERY_WORKER | INCIDENT_RESPONSE | STATUS_ONLY | PACKET_REFINEMENT",
  "selectedProductId": "exact-product-id-or-null",
  "selectedProductName": "exact-product-name-or-null",
  "selectedWorkflow": "exact workflow",
  "artifactMode": "FULL_PRODUCT_ZIP | COMPACT_POINTER | CUMULATIVE_LEAN_SOURCE | APPROVED_SEED",
  "artifactModeReason": "why this mode applies",
  "authorityPacketId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V30-INDIVIDUAL-FIRST-PROFILE-GROWTH",
  "ownerRuleCanonicalSha256": "ad05f8c4f5ae2eeb831b3dd2440623582cf998827308e46bd27c7ea8102f8653",
  "ownerRuleCount": 111,
  "authoritativeFullSource": {
    "repository": "owner/repository-or-null",
    "sourceCommit": "40-character-commit-or-null",
    "tagOrRelease": "value-or-null",
    "fullArtifactSha256": "64-hex-or-null",
    "fullArtifactSizeBytes": 0,
    "retrievalStatus": "NOT_REQUIRED | VERIFIED | BLOCKED"
  },
  "cleanDeploymentStatus": "PROHIBITED | NOT_YET_QUALIFIED | ELIGIBLE_AFTER_GATES",
  "inputArtifacts": [],
  "evidenceBasis": [],
  "routingConfidence": "HIGH | BLOCKED",
  "catalogState": "LISTED | CATALOG_PENDING | NOT_APPLICABLE",
  "ownerRuleChain": "PASS | BLOCKED",
  "ambiguities": []
}
```

Do not start code changes from a compact pointer until `retrievalStatus` is `VERIFIED`. Do not describe a compact pointer as the complete product ZIP.

# VALUE, RISK, RESEARCH, PROFILE, AND RELEASE DISCIPLINE — V27

## 1. Decision order
Protect users and data; preserve working live capability; satisfy durable owner rules; deliver the highest verified user and professional value; maintain simplicity; then optimize speed and breadth.

## 2. Release-scope test
A proposed change belongs in the current release when it has supported value, compatible dependencies, complete English/Spanish behavior, testable acceptance criteria, operational support, observability, and a safe migration or rollback path. Unrelated high-risk changes should be separated when that lowers combined failure risk. This is not a one-change rule.

## 3. Research quality test
For each material source, record who published it, when it was accessed, whether the information is current, why it is relevant, what conflicts exist, and what product decision follows. Use official or primary sources for legal, regulatory, eligibility, status, deadline, provider, and other unstable facts whenever available.

## 4. Profile publication test
Before publication, claim invitation, outreach, featuring, or opportunity distribution, confirm deduplication, identity, status, specialty relevance, source freshness, contact evidence, portal acceptance, neutral presentation, correction path, suppression path, and date of recheck.

## 5. Innovation test
Score each material proposal for user need, professional value, simplicity, accessibility, bilingual completeness, privacy, security, legal safeguards, maintainability, support burden, operating cost, and measurable acceptance. Implement, defer, or reject with evidence.

## 6. Live-learning test
Use uncached desktop/mobile journeys, support findings, accessibility and reliability evidence, consented feedback, and privacy-minimized aggregate signals. Do not use sensitive legal facts, documents, messages, or unnecessary identifiers for analytics. Record the decision changed by the evidence.

## 7. Rule-chain test
Every work order and release record must carry the V27 packet ID, canonical rule hash, rule count, and PASS/BLOCKED validation result. No product may be qualified or promoted when the chain is missing or mismatched.

## 8. Deferred-value continuity
Every deferred high-value item must include title, value, evidence, priority, dependencies, risk, and acceptance criteria. The next material build must review unresolved items and record implementation, continued deferral, or rejection with reason.

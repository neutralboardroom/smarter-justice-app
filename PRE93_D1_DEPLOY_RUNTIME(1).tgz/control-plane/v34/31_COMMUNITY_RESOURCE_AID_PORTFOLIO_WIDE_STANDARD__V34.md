# COMMUNITY RESOURCE AID PORTFOLIO-WIDE STANDARD — V34

**Packet ID:** `SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V34-COMMUNITY-RESOURCE-AID-PORTFOLIO-ALIGNMENT-UNIFIED-COMMUNITY-ENTRY`  
**Effective:** 2026-08-05T23:08:00-04:00

Community Resource Aid is a free network-wide public benefit. It belongs in Smarter Justice and every portfolio product through a complete central hub or a clear specialty-aware handoff. It is not an eleventh legal practice area.

## Required implementation by product type

- **Smarter Justice:** complete bilingual central resource hub, community-centered homepage entry, focused category links, help-for-someone-else path, Community Partner Tools, and one unified professional dashboard that treats community resources as shareable value.
- **Ordinary legal, tax, and immigration products:** a visible Community Help entry, specialty-relevant explanation, safe handoff to the central hub, and direct specialized resources only when current and verified. Do not clone the full hub merely to satisfy the rule.
- **Domestic Violence Aid and other specialized safety products:** preserve the dedicated brand and safety model, include direct central-hub handoff, quick exit and monitored-device guidance, and do not weaken specialized privacy protections.
- **Back-office or non-public tools:** document applicability; link or integrate only where it serves users or professionals without creating public-data risk.

## Coverage floor

Use `32_COMMUNITY_RESOURCE_AID_CANONICAL_SCOPE__V34.json`. Preserve all 22 canonical categories, including substance-use issues of all types and human, sex, labor, and child trafficking. Add useful verified categories when warranted; never silently remove a category.

## Safety and truth

Basic resource discovery requires no account and no private narrative. Do not collect names, precise locations, case facts, health histories, trafficking details, or domestic-violence facts merely to display links. Do not claim dispatch, guaranteed placement, treatment, legal representation, law-enforcement action, or clinical service. Provide emergency and digital-safety boundaries without alarmist language.

## Drug and substance scope

Cover any substance, alcohol, polysubstance use, treatment, recovery, prevention, harm reduction, family support, overdose response, naloxone, and poison exposure. Do not offer or imply a drug-testing, screening, laboratory, product-testing, or “drug check” service under the current authority.

## Portfolio release gate

Every material build must validate `TEMPLATES/COMMUNITY_RESOURCE_AID_ALIGNMENT_RECEIPT.template.json` against its schema, test English and Spanish entry points, recheck current official resources, and truthfully record live verification. Missing alignment is a carry-forward deficit, not a reason to falsify completion.

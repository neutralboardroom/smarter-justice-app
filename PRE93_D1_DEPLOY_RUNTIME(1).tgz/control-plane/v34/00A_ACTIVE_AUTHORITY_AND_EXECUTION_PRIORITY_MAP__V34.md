# ACTIVE AUTHORITY AND EXECUTION PRIORITY MAP — V34

**Packet ID:** `SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-05-V34-COMMUNITY-RESOURCE-AID-PORTFOLIO-ALIGNMENT-UNIFIED-COMMUNITY-ENTRY`

Priority controls reading and execution order. It does not make lower-level material optional.

## Authority precedence
1. Current explicit Roger Gillman instruction consistent with durable rules.
2. Current production capability state.
3. Exact V34 durable owner-rule register and lock.
4. Validated routing declaration and selected command.
5. V34 Community Resource Aid, ten-area, professional, Business Law Aid, source, schema, template, and deployment standards.
6. Historical authority for provenance and recovery, never to restart obsolete commands.

## P0 — validate
Read files 00, 00A, 00B, 02, 03, 04, 13, 16, and 27.

## P1 — execute one selected command
Use 05A for active Smarter Justice deployment recovery; otherwise use 05 through 12 as routed. Do not delay safe work to reread the complete historical archive.

## P2 — required material outcomes
- useful comprehensive improvement without churn;
- Community Resource Aid alignment under OR-132 through OR-143;
- ten equal launch-area and unified-professional truth;
- individual-first profile growth where applicable;
- current research, verified links, English/Spanish parity, accessibility, privacy, data continuity, payments, storage, AI safety, deployment, backup, rollback, and live verification;
- V33 deployment-recovery discipline when applicable.

## P3 — evidence and release
Produce all exact receipts, including Community Resource Aid Alignment Receipt, profile and voice receipts where applicable, full-source or compact continuity records, SBOM/provenance, tests, and truthful deployment evidence.

## P4 — history and learning
Update cross-version learning and open deeper historical authority only as needed. Lower priority never means optional.

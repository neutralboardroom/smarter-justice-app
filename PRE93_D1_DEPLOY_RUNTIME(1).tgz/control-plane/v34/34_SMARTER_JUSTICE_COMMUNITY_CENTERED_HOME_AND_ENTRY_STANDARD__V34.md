# SMARTER JUSTICE COMMUNITY-CENTERED HOME AND ENTRY STANDARD — V34

Smarter Justice is both the legal-network front door and a community starting point. Preserve a bright, clean, accessible homepage with four understandable choices: practical help today; safety or crisis support; legal or tax help; and attorneys, firms, or community organizations.

Community Resource Aid should appear before or at equal prominence with legal category cards, while the ten equal areas remain visible and unchanged. Use direct category focus links rather than sending every community need to an undifferentiated page. The user must be able to browse without an account, upload, narrative intake, tracking, or saved sensitive selection.

English and Spanish must communicate the same decisions and boundaries. The homepage must not imply that Smarter Justice dispatches help, guarantees services, or has live integrations that exact evidence does not prove.

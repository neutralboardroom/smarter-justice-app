'use strict';
module.exports=Object.freeze({queue:require('../OWNER_ACTION_QUEUE_V1.7.66.json'),readiness:require('../OWNER_ACTION_READINESS_V1.7.66.json')});

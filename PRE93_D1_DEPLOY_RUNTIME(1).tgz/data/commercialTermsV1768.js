'use strict';
module.exports=Object.freeze(require('../COMMERCIAL_TERMS_AND_ENTITLEMENT_MANIFEST_V1.7.68.json'));

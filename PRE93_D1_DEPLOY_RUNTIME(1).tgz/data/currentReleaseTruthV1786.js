'use strict';
module.exports={
  "schema": "smarter-justice-current-release-truth",
  "schemaVersion": "1.4.0",
  "releaseVersion": "1.7.86",
  "generatedAt": "2026-08-04T19:19:00-04:00",
  "selectedBase": {
    "filename": "smarter-justice-v1.7.85.zip",
    "version": "1.7.85",
    "sha256": "a7969080f79dcc6b7aadaa16c30cad0b726cffb777ecb87c6f08582805e6ecda",
    "sizeBytes": 9184676,
    "entries": 3261,
    "files": 3236,
    "directories": 25,
    "dependencyIndependentParts": 153,
    "totalReadinessParts": 154,
    "testLogSha256": "d3ae23a30cace8652455cff0a34c5f9464169b07b526c84abae57170459a8333"
  },
  "rollbackArtifact": {
    "filename": "smarter-justice-v1.7.85.zip",
    "version": "1.7.85",
    "sha256": "a7969080f79dcc6b7aadaa16c30cad0b726cffb777ecb87c6f08582805e6ecda",
    "sizeBytes": 9184676,
    "entries": 3261,
    "files": 3236,
    "directories": 25,
    "dependencyIndependentParts": 153,
    "totalReadinessParts": 154,
    "testLogSha256": "d3ae23a30cace8652455cff0a34c5f9464169b07b526c84abae57170459a8333"
  },
  "sourcePackage": {
    "filename": "smarter-justice-v1.7.86.zip",
    "version": "1.7.86",
    "dependencyIndependentParts": 154,
    "totalReadinessParts": 155,
    "identityState": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED",
    "packageJsonSha256": "f47b660ffe5b0e9e70e745a19fc5135e7f93426d1468b1009fd90ddad0462833",
    "packageLockSha256": "ef02d12ff033939422efd918d33ca4a88fc749b02df0bf1b5469642d840dc022",
    "sbomSha256": "004d41fe3d03a3e071e75438b9cef51d3fa736306bc508f954a3a05beb7659af"
  },
  "finalArchive": {
    "filename": "smarter-justice-v1.7.86.zip",
    "version": "1.7.86",
    "identityState": "REPORTED_AFTER_IMMUTABLE_PACKAGING",
    "sha256": null,
    "sizeBytes": null
  },
  "activeMasterPair": {
    "receiptId": "MPCR-2026-07-31-E1-R0-05F4296ED378",
    "transactionId": "MPPT-2026-07-31-SJ8-FP26-304CB87BF174",
    "pairEpoch": 1,
    "pairRevision": 0,
    "receiptSha256": "4dd826cb0f9d89e41528b9732f250899cab45ce89766ae7fdfdb8a44d48d906e",
    "centralMasterSha256": "89f49e1433d05a937a31c2144e42e408a94c4502d8c388ad5f3a6eae7ad5aa68",
    "portalFamilyMasterSha256": "fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f",
    "baselineId": "DRB-2026-07-31-DUR001-DUR043-V2",
    "semanticCapsuleSha256": "3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8"
  },
  "portalAuthority": {
    "record": "INITIAL_PORTAL_AUTHORITY_V1.7.75.json",
    "evidenceBoundary": "OWNER_RECORDED_OR_HANDOFF_RECORDED_NOT_CURRENT_CHAT_PORTAL_INSPECTION",
    "liveConnectionsOpened": false,
    "automaticWritesOpened": false
  },
  "ownerLaunchActionPacket": {
    "record": "OWNER_LAUNCH_ACTION_PACKET_V1.7.75.json",
    "state": "PRIVATE_VALIDATED_NONSECRET_EXECUTION_PACKET",
    "readyNowCount": 4
  },
  "production": {
    "lastVerifiedVersion": "1.6.1",
    "deploymentAuthorized": false,
    "deploymentState": "NOT_DEPLOYED",
    "deployed": false
  },
  "launchState": "NO_GO",
  "deploymentAuthorized": false,
  "publicDisplay": {
    "currentVersion": "1.7.86",
    "sourceAndRollback": "smarter-justice-v1.7.85.zip",
    "finalIdentity": "Reported after immutable packaging; never embedded in the ZIP",
    "promptPack": "V20 active-live portfolio qualification with simple bilingual entry routes and truthful closed live gates.",
    "launch": "NO_GO",
    "deployment": "Not authorized by source qualification alone",
    "sourceVersion": "1.7.85"
  },
  "validationState": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED",
  "currentPromptPack": {
    "packId": "SJP-V20-ACTIVE-LIVE-PORTFOLIO",
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-04-V20-ACTIVE-LIVE-PORTFOLIO",
    "packetSha256": "c0f328d2184c092b8a4ad68a18709e6890496788e15256549ccad700d82c9def",
    "standingAuthorizationId": "OWNER-V20-PORTFOLIO-LIVE-2026-08-04",
    "mode": "BUILD_QUALIFY_STAGE_LAUNCH_HANDOFF",
    "canonicalCommitProven": false,
    "productionActivationPerformed": false
  },
  "candidateArtifact": {
    "filename": "smarter-justice-v1.7.86-candidate-a.zip",
    "sha256": "33bc9e27b3136bb7f97d69604ecf490b93a9d51c5c70f93a3ab8a06d0a4b1213",
    "sizeBytes": 9387743,
    "state": "CANDIDATE_ACCEPTED_TWO_DETERMINISTIC_BUILDS_TWO_FRESH_EXTRACTIONS",
    "entries": 3302
  },
  "deploymentReadiness": {
    "record": "DEPLOYMENT_READINESS_V1.7.75.json",
    "state": "LOCAL_LAUNCH_DAY_ORCHESTRATION_ACCEPTED_ALL_PRODUCT_PREFLIGHT_PENDING"
  },
  "packId": "SJP-2026-08-02-C15-P37-D11-V13",
  "durableRuleBaseline": "DRB-2026-08-02-DUR001-DUR086-V13",
  "presealArtifact": {
    "state": "CANDIDATE_ACCEPTED_TWO_DETERMINISTIC_BUILDS_TWO_FRESH_EXTRACTIONS",
    "candidateSha256": "33bc9e27b3136bb7f97d69604ecf490b93a9d51c5c70f93a3ab8a06d0a4b1213",
    "candidateSizeBytes": 9387743
  },
  "recoveryLineage": {
    "selectedMode": "BUILD_QUALIFY_STAGE_LAUNCH_HANDOFF",
    "sourceArtifact": "smarter-justice-v1.7.85.zip",
    "sourceSha256": "a7969080f79dcc6b7aadaa16c30cad0b726cffb777ecb87c6f08582805e6ecda",
    "governingPacket": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-04-V20-ACTIVE-LIVE-PORTFOLIO",
    "governingPacketSha256": "c0f328d2184c092b8a4ad68a18709e6890496788e15256549ccad700d82c9def"
  },
  "v12ContinuousImprovement": {
    "packetSha256": "37d90cab818b71613c388bf195b08d129eb569dd183de5358f32dd335975a1d5",
    "innovationPlan": "CONTINUOUS_SELF_IMPROVEMENT_AND_INNOVATION_PLAN_V1.7.86.json",
    "dualImprovementReport": "PRODUCT_AND_PROMPT_DUAL_IMPROVEMENT_REPORT_V1.7.86.json",
    "crossVersionLearning": "CROSS_VERSION_LEARNING_LEDGER_V1.7.86.json",
    "releaseEvidenceCoverageContract": "RELEASE_EVIDENCE_COVERAGE_CONTRACT_V1.7.86.json"
  },
  "workingTreeAcceptance": {
    "record": "WORKING_TREE_ACCEPTANCE_V1.7.86.json",
    "state": "FINALIZED_WORKING_TREE_ACCEPTED",
    "runs": 2,
    "commandsPerRun": 154,
    "identicalOutput": true,
    "testLogSha256": "5c657a85ce885e37f589e3283a6f700ebce811716def1ee2cb37f2fac4941beb",
    "manifestSha256": "451c7c13b5a0b1b06cf8b4b283b3f779ebbc020cc88ff15b0ccaf6c46504d427"
  },
  "candidateAcceptanceRecord": "CANDIDATE_ARTIFACT_ACCEPTANCE_V1.7.86.json",
  "finalSourceAcceptanceRecord": "FINAL_SOURCE_ACCEPTANCE_V1.7.86.json",
  "openAiLaunch": {
    "launchBatchId": "SJP-OPENAI-LIVE-2026-08-03-BATCH-02",
    "overlayCheckpoint": "OPENAI_LAUNCH_OVERLAY_CHECKPOINT_V1.7.85.json",
    "gatewayContract": "AI_GATEWAY_CONTRACT_V1.7.85.json",
    "modelConfiguration": "AI_MODEL_CONFIGURATION_V1.7.85.json",
    "toolPromptRegistry": "AI_TOOL_AND_PROMPT_REGISTRY_V1.7.85.json",
    "capabilityMatrix": "FIVE_PRODUCT_AI_CAPABILITY_MATRIX_V1.7.85.json",
    "vendorPolicy": "OPENAI_ONLY",
    "keyConfigured": false,
    "liveSmokePassed": false,
    "portalCompatibilityReceipts": 0,
    "deploymentAuthorized": false,
    "launchState": "NO_GO"
  },
  "v14": {
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "mode": "MODE_E_RECOVERY",
    "artifactBindingReceipt": "ARTIFACT_BINDING_AND_MODE_RECEIPT.json",
    "ownerReceipt": "OWNER_RECEIPT.txt",
    "releasePayloadInventory": "RELEASE_PAYLOAD_INVENTORY_SHA256.txt",
    "unifiedLiveOperations": "V14_UNIFIED_LIVE_OPERATIONS_REGISTER_V1.7.85.json",
    "finalDeliveryIdentity": "REPORTED_AFTER_PACKAGING",
    "liveEvidenceConnector": "V14_LIVE_EVIDENCE_CONNECTOR_CONTRACT_V1.7.85.json",
    "receiptAutomation": "V14_RELEASE_RECEIPT_AUTOMATION_V1.7.85.json",
    "evidenceBatchWorkspace": "V14_EVIDENCE_BATCH_WORKSPACE_CONTRACT_V1.7.85.json",
    "detachedDeliveryReceiptContract": "V14_DETACHED_FINAL_DELIVERY_RECEIPT_CONTRACT_V1.7.85.json",
    "evidenceReadinessPlanner": "V14_EVIDENCE_READINESS_PLANNER_CONTRACT_V1.7.85.json",
    "segmentedAcceptanceManifest": "ACCEPTANCE_SUITE_MANIFEST_V1.7.85.json",
    "segmentedAcceptanceManifestSha256": "5aeddf6644a0ed303f4c80a75d6c603ad5f117044e05cac495f640dad685e4b1",
    "evidenceCollectionPacket": "V14_EVIDENCE_COLLECTION_PACKET_CONTRACT_V1.7.85.json",
    "acceptanceEvidenceBundle": "V14_ACCEPTANCE_EVIDENCE_BUNDLE_CONTRACT_V1.7.85.json",
    "evidenceBatchApplicationAuthorization": "V14_EVIDENCE_BATCH_APPLICATION_AUTHORIZATION_CONTRACT_V1.7.85.json",
    "detachedPublicationManifest": "V14_DETACHED_PUBLICATION_MANIFEST_CONTRACT_V1.7.85.json",
    "evidenceApplicationTransactionPackage": "V14_EVIDENCE_APPLICATION_TRANSACTION_PACKAGE_CONTRACT_V1.7.85.json",
    "detachedReleaseHandoff": "V14_DETACHED_RELEASE_HANDOFF_CONTRACT_V1.7.85.json"
  },
  "finalSource": {
    "state": "FINAL_SOURCE_SEALED_PENDING_FINAL_ARCHIVE_ACCEPTANCE",
    "releaseVersion": "1.7.86",
    "commandsPerRun": 154,
    "runs": 2,
    "identicalOutput": true,
    "testLogSha256": "5c657a85ce885e37f589e3283a6f700ebce811716def1ee2cb37f2fac4941beb",
    "candidateSha256": "33bc9e27b3136bb7f97d69604ecf490b93a9d51c5c70f93a3ab8a06d0a4b1213",
    "candidateSizeBytes": 9387743
  },
  "v20": {
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-04-V20-ACTIVE-LIVE-PORTFOLIO",
    "packetSha256": "c0f328d2184c092b8a4ad68a18709e6890496788e15256549ccad700d82c9def",
    "mode": "BUILD_QUALIFY_STAGE_LAUNCH_HANDOFF",
    "binding": "V20_PACKET_BINDING_V1.7.86.json",
    "capabilityRegister": "V20_LIVE_CAPABILITY_REGISTER_V1.7.86.json",
    "deploymentHandoff": "DEPLOYMENT_HANDOFF.json",
    "homepageAcceptance": "HOMEPAGE_SIMPLICITY_ACCEPTANCE_V1.7.86.json",
    "spanishAcceptance": "SPANISH_LIVE_ACCEPTANCE_V1.7.86.json",
    "liveCapabilityAcceptance": "LIVE_CAPABILITY_ACCEPTANCE_V1.7.86.json",
    "productionDeploymentPerformed": false
  }
};

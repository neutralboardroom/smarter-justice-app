'use strict';
module.exports=Object.freeze(require('../COORDINATED_PROMPT_PACK_AUTHORITY_V1.7.69.json'));

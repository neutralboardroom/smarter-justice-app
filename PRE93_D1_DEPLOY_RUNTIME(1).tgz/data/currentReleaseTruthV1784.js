'use strict';
module.exports={
  "schema": "smarter-justice-current-release-truth",
  "schemaVersion": "1.4.0",
  "releaseVersion": "1.7.84",
  "generatedAt": "2026-08-04T11:51:00-04:00",
  "selectedBase": {
    "filename": "smarter-justice-v1.7.83.zip",
    "version": "1.7.83",
    "sha256": "41eff94948e36b79ff5cf7e5d2b25c9bf145935cad5980c034c0b39254d4dbfc",
    "sizeBytes": 8888322,
    "entries": 3171,
    "files": 3147,
    "directories": 24,
    "uncompressedBytes": 26379933,
    "compressedBytes": 8406618,
    "payloadInventoryRecords": 3144,
    "payloadInventorySha256": "2b50789978d0ec4ea914164e647758e3f410427e8066dee2d8e63fcb03d1d1cb",
    "inventoryRecords": 3146,
    "inventorySha256": "cfbf49c89af963d0ea7d7a9bed25cda3a6a2652e93dc6a8c021b72b9c05d7a8c",
    "treeSha256": "cfbf49c89af963d0ea7d7a9bed25cda3a6a2652e93dc6a8c021b72b9c05d7a8c",
    "packageJsonSha256": "adb5e986a2f8062ffae5bee7374ded80157768d62f74af0e412de4a56a1eb557",
    "packageLockSha256": "e795006890fa9230e3bbd9759c3136485d9cc93237deb598f293ee56c4ca04f8",
    "sbomSha256": "88c32b78db48539944662ea3afa2f9fa51af01ffa0dec5c943d6f34f2c605ce4",
    "dependencyIndependentParts": 145,
    "totalReadinessParts": 146,
    "testLogSha256": "65997d8bb250b85b36c1c111f452a3b3caf4f044670fe01e276a21edb5240ef5"
  },
  "rollbackArtifact": {
    "filename": "smarter-justice-v1.7.83.zip",
    "version": "1.7.83",
    "sha256": "41eff94948e36b79ff5cf7e5d2b25c9bf145935cad5980c034c0b39254d4dbfc",
    "sizeBytes": 8888322,
    "entries": 3171,
    "files": 3147,
    "directories": 24,
    "uncompressedBytes": 26379933,
    "compressedBytes": 8406618,
    "payloadInventoryRecords": 3144,
    "payloadInventorySha256": "2b50789978d0ec4ea914164e647758e3f410427e8066dee2d8e63fcb03d1d1cb",
    "inventoryRecords": 3146,
    "inventorySha256": "cfbf49c89af963d0ea7d7a9bed25cda3a6a2652e93dc6a8c021b72b9c05d7a8c",
    "treeSha256": "cfbf49c89af963d0ea7d7a9bed25cda3a6a2652e93dc6a8c021b72b9c05d7a8c",
    "packageJsonSha256": "adb5e986a2f8062ffae5bee7374ded80157768d62f74af0e412de4a56a1eb557",
    "packageLockSha256": "e795006890fa9230e3bbd9759c3136485d9cc93237deb598f293ee56c4ca04f8",
    "sbomSha256": "88c32b78db48539944662ea3afa2f9fa51af01ffa0dec5c943d6f34f2c605ce4",
    "dependencyIndependentParts": 145,
    "totalReadinessParts": 146,
    "testLogSha256": "65997d8bb250b85b36c1c111f452a3b3caf4f044670fe01e276a21edb5240ef5"
  },
  "sourcePackage": {
    "filename": "smarter-justice-v1.7.84.zip",
    "version": "1.7.84",
    "dependencyIndependentParts": 147,
    "totalReadinessParts": 148,
    "identityState": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED",
    "packageJsonSha256": "20c011399ddd5236b330921ab74f8f3082d2a23897c0dcab24e49df0a82e3cbf",
    "packageLockSha256": "cd669e7745b6c13791cf4a35fbbd0f059bc520c4aeed69d430ee9d98f7ee441a",
    "sbomSha256": "b9e8a25b0d59ca81f34aae580c5101f16cbd51d344340db37e3450b8baa5bc85"
  },
  "finalArchive": {
    "filename": "smarter-justice-v1.7.84.zip",
    "version": "1.7.84",
    "identityState": "REPORTED_AFTER_IMMUTABLE_PACKAGING",
    "sha256": null,
    "sizeBytes": null
  },
  "activeMasterPair": {
    "receiptId": "MPCR-2026-07-31-E1-R0-05F4296ED378",
    "transactionId": "MPPT-2026-07-31-SJ8-FP26-304CB87BF174",
    "pairEpoch": 1,
    "pairRevision": 0,
    "receiptSha256": "4dd826cb0f9d89e41528b9732f250899cab45ce89766ae7fdfdb8a44d48d906e",
    "centralMasterSha256": "89f49e1433d05a937a31c2144e42e408a94c4502d8c388ad5f3a6eae7ad5aa68",
    "portalFamilyMasterSha256": "fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f",
    "baselineId": "DRB-2026-07-31-DUR001-DUR043-V2",
    "semanticCapsuleSha256": "3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8"
  },
  "portalAuthority": {
    "record": "INITIAL_PORTAL_AUTHORITY_V1.7.75.json",
    "evidenceBoundary": "OWNER_RECORDED_OR_HANDOFF_RECORDED_NOT_CURRENT_CHAT_PORTAL_INSPECTION",
    "liveConnectionsOpened": false,
    "automaticWritesOpened": false
  },
  "ownerLaunchActionPacket": {
    "record": "OWNER_LAUNCH_ACTION_PACKET_V1.7.75.json",
    "state": "PRIVATE_VALIDATED_NONSECRET_EXECUTION_PACKET",
    "readyNowCount": 4
  },
  "production": {
    "lastVerifiedVersion": "1.6.1",
    "deploymentAuthorized": false,
    "deploymentState": "NOT_DEPLOYED",
    "deployed": false
  },
  "launchState": "NO_GO",
  "deploymentAuthorized": false,
  "publicDisplay": {
    "currentVersion": "1.7.84",
    "sourceAndRollback": "smarter-justice-v1.7.83.zip",
    "finalIdentity": "Reported after immutable packaging; never embedded in the ZIP",
    "promptPack": "V14 exact artifact binding, preview-only batch authorization, detached publication-manifest verification, unified live operations, and non-self-referential release automation accepted locally; external live evidence remains separate.",
    "launch": "NO_GO",
    "deployment": "Not authorized",
    "sourceVersion": "1.7.83"
  },
  "validationState": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED",
  "currentPromptPack": {
    "packId": "SJP-2026-08-02-C15-P37-D11-V13",
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "canonicalCommitProven": false,
    "baselineId": "DRB-2026-08-02-DUR001-DUR086-V13",
    "ruleCount": 86,
    "deploymentFile4State": "PRESERVED_INSIDE_V14"
  },
  "candidateArtifact": {
    "filename": "smarter-justice-v1.7.84-candidate-a.zip",
    "sha256": "188d95587f0d89b6b29bfd93f626ecacf8112b3cb3008c6f5b75c098bd5ea061",
    "sizeBytes": 8939064,
    "entries": 3209,
    "files": 3185,
    "directories": 24,
    "uncompressedBytes": 26508110,
    "compressedBytes": 8451016,
    "payloadInventoryRecords": 3182,
    "payloadInventorySha256": "8a26b8dd816dd45e154b400f651424f1aef9005abd41413460288a29cc695e35",
    "legacyInventoryRecords": 3184,
    "legacyInventorySha256": "25a2b88703941429732d6c158dc73a48edc5275103e4f2f5841bf17ad02403b2",
    "state": "CANDIDATE_ACCEPTED"
  },
  "deploymentReadiness": {
    "record": "DEPLOYMENT_READINESS_V1.7.75.json",
    "state": "LOCAL_LAUNCH_DAY_ORCHESTRATION_ACCEPTED_ALL_PRODUCT_PREFLIGHT_PENDING"
  },
  "packId": "SJP-2026-08-02-C15-P37-D11-V13",
  "durableRuleBaseline": "DRB-2026-08-02-DUR001-DUR086-V13",
  "presealArtifact": {
    "candidateSha256": "188d95587f0d89b6b29bfd93f626ecacf8112b3cb3008c6f5b75c098bd5ea061",
    "candidateSizeBytes": 8939064,
    "state": "CANDIDATE_ACCEPTED_NONCIRCULAR"
  },
  "recoveryLineage": {
    "record": "RECOVERY_LINEAGE_RECEIPT_V1.7.75.json",
    "inheritedExactRecoveryBase": "smarter-justice-v1.7.73.zip",
    "unavailableIntermediate": "smarter-justice-v1.7.74.zip",
    "byteExactIntermediateRecoveryClaimed": false,
    "currentExactSource": "smarter-justice-v1.7.83.zip"
  },
  "v12ContinuousImprovement": {
    "packetSha256": "37d90cab818b71613c388bf195b08d129eb569dd183de5358f32dd335975a1d5",
    "innovationPlan": "CONTINUOUS_SELF_IMPROVEMENT_AND_INNOVATION_PLAN_V1.7.84.json",
    "dualImprovementReport": "PRODUCT_AND_PROMPT_DUAL_IMPROVEMENT_REPORT_V1.7.84.json",
    "crossVersionLearning": "CROSS_VERSION_LEARNING_LEDGER_V1.7.84.json",
    "releaseEvidenceCoverageContract": "RELEASE_EVIDENCE_COVERAGE_CONTRACT_V1.7.84.json"
  },
  "workingTreeAcceptance": {
    "record": "WORKING_TREE_ACCEPTANCE_V1.7.84.json",
    "runs": 2,
    "identicalOutput": true,
    "testLogSha256": "433142cc3486e09e8e8131f5a5415f9c1d77fd5a770e89de4e39e7ab99efe7d6",
    "state": "FINALIZED_WORKING_TREE_ACCEPTED"
  },
  "candidateAcceptanceRecord": "CANDIDATE_ARTIFACT_ACCEPTANCE_V1.7.84.json",
  "finalSourceAcceptanceRecord": "FINAL_SOURCE_ACCEPTANCE_V1.7.84.json",
  "openAiLaunch": {
    "launchBatchId": "SJP-OPENAI-LIVE-2026-08-03-BATCH-02",
    "overlayCheckpoint": "OPENAI_LAUNCH_OVERLAY_CHECKPOINT_V1.7.84.json",
    "gatewayContract": "AI_GATEWAY_CONTRACT_V1.7.84.json",
    "modelConfiguration": "AI_MODEL_CONFIGURATION_V1.7.84.json",
    "toolPromptRegistry": "AI_TOOL_AND_PROMPT_REGISTRY_V1.7.84.json",
    "capabilityMatrix": "FIVE_PRODUCT_AI_CAPABILITY_MATRIX_V1.7.84.json",
    "vendorPolicy": "OPENAI_ONLY",
    "keyConfigured": false,
    "liveSmokePassed": false,
    "portalCompatibilityReceipts": 0,
    "deploymentAuthorized": false,
    "launchState": "NO_GO"
  },
  "v14": {
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "mode": "MODE_B_EXISTING_CHAT_PACKET_ONLY",
    "artifactBindingReceipt": "ARTIFACT_BINDING_AND_MODE_RECEIPT.json",
    "ownerReceipt": "OWNER_RECEIPT.txt",
    "releasePayloadInventory": "RELEASE_PAYLOAD_INVENTORY_SHA256.txt",
    "unifiedLiveOperations": "V14_UNIFIED_LIVE_OPERATIONS_REGISTER_V1.7.84.json",
    "finalDeliveryIdentity": "REPORTED_AFTER_PACKAGING",
    "liveEvidenceConnector": "V14_LIVE_EVIDENCE_CONNECTOR_CONTRACT_V1.7.84.json",
    "receiptAutomation": "V14_RELEASE_RECEIPT_AUTOMATION_V1.7.84.json",
    "evidenceBatchWorkspace": "V14_EVIDENCE_BATCH_WORKSPACE_CONTRACT_V1.7.84.json",
    "detachedDeliveryReceiptContract": "V14_DETACHED_FINAL_DELIVERY_RECEIPT_CONTRACT_V1.7.84.json",
    "evidenceReadinessPlanner": "V14_EVIDENCE_READINESS_PLANNER_CONTRACT_V1.7.84.json",
    "segmentedAcceptanceManifest": "ACCEPTANCE_SUITE_MANIFEST_V1.7.84.json",
    "segmentedAcceptanceManifestSha256": "cb282a8f578de317c3c6e6c91bad80702a95ff1e2b63f11fee1370875c0774a5",
    "evidenceCollectionPacket": "V14_EVIDENCE_COLLECTION_PACKET_CONTRACT_V1.7.84.json",
    "acceptanceEvidenceBundle": "V14_ACCEPTANCE_EVIDENCE_BUNDLE_CONTRACT_V1.7.84.json",
    "evidenceBatchApplicationAuthorization": "V14_EVIDENCE_BATCH_APPLICATION_AUTHORIZATION_CONTRACT_V1.7.84.json",
    "detachedPublicationManifest": "V14_DETACHED_PUBLICATION_MANIFEST_CONTRACT_V1.7.84.json"
  },
  "finalSource": {
    "state": "FINAL_SOURCE_ACCEPTED",
    "runs": 2,
    "commandsPerRun": 147,
    "identicalOutput": true,
    "testLogSha256": "433142cc3486e09e8e8131f5a5415f9c1d77fd5a770e89de4e39e7ab99efe7d6",
    "candidateSha256": "188d95587f0d89b6b29bfd93f626ecacf8112b3cb3008c6f5b75c098bd5ea061",
    "candidateSizeBytes": 8939064
  }
};

'use strict';
module.exports=Object.freeze({queue:require('../OWNER_ACTION_QUEUE_V1.7.61.json'),readiness:require('../OWNER_ACTION_READINESS_V1.7.61.json')});

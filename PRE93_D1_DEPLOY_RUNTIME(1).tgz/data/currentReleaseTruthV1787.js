'use strict';
module.exports=require('../CURRENT_RELEASE_TRUTH_V1.7.87.json');

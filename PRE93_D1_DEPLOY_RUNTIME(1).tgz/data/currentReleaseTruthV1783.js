'use strict';
module.exports={
  "schema": "smarter-justice-current-release-truth",
  "schemaVersion": "1.4.0",
  "releaseVersion": "1.7.83",
  "generatedAt": "2026-08-03T19:45:00-04:00",
  "selectedBase": {
    "filename": "smarter-justice-v1.7.82.zip",
    "version": "1.7.82",
    "sha256": "61fea278a69055915e9b4b916e4b64ec514614f1746cacf659a6931ccd0228b1",
    "sizeBytes": 8829574,
    "entries": 3135,
    "files": 3111,
    "directories": 24,
    "uncompressedBytes": 26230593,
    "compressedBytes": 8353654,
    "payloadInventoryRecords": 3108,
    "payloadInventorySha256": "e0a33aaf4935ec7fc00b68b6b32fef9e3c17060d80090f7698502175b33b5cca",
    "inventoryRecords": 3110,
    "inventorySha256": "c41f6f11f4845894431c95f58fef6762eb272d8d7da460bc5678e48575079044",
    "treeSha256": "c41f6f11f4845894431c95f58fef6762eb272d8d7da460bc5678e48575079044",
    "packageJsonSha256": "db426c566ea41c9be7a899718bbbe904a624922071e5f04ddc4b3b849c141a67",
    "packageLockSha256": "0e7bd658a2618f69848bf11a8286769d560693a08096543248ec41126298bd68",
    "sbomSha256": "a5fa82094de6453a319371c6c38ce59ce310cd66ef67bac2d73b43efcb37e449",
    "dependencyIndependentParts": 143,
    "totalReadinessParts": 144,
    "testLogSha256": "75ac27c328cacc1f39f3d92b675c27325662b9bc5a54f2de00556b9fe4306c11"
  },
  "rollbackArtifact": {
    "filename": "smarter-justice-v1.7.82.zip",
    "version": "1.7.82",
    "sha256": "61fea278a69055915e9b4b916e4b64ec514614f1746cacf659a6931ccd0228b1",
    "sizeBytes": 8829574,
    "entries": 3135,
    "files": 3111,
    "directories": 24,
    "uncompressedBytes": 26230593,
    "compressedBytes": 8353654,
    "payloadInventoryRecords": 3108,
    "payloadInventorySha256": "e0a33aaf4935ec7fc00b68b6b32fef9e3c17060d80090f7698502175b33b5cca",
    "inventoryRecords": 3110,
    "inventorySha256": "c41f6f11f4845894431c95f58fef6762eb272d8d7da460bc5678e48575079044",
    "treeSha256": "c41f6f11f4845894431c95f58fef6762eb272d8d7da460bc5678e48575079044",
    "packageJsonSha256": "db426c566ea41c9be7a899718bbbe904a624922071e5f04ddc4b3b849c141a67",
    "packageLockSha256": "0e7bd658a2618f69848bf11a8286769d560693a08096543248ec41126298bd68",
    "sbomSha256": "a5fa82094de6453a319371c6c38ce59ce310cd66ef67bac2d73b43efcb37e449",
    "dependencyIndependentParts": 143,
    "totalReadinessParts": 144,
    "testLogSha256": "75ac27c328cacc1f39f3d92b675c27325662b9bc5a54f2de00556b9fe4306c11"
  },
  "sourcePackage": {
    "filename": "smarter-justice-v1.7.83.zip",
    "version": "1.7.83",
    "dependencyIndependentParts": 145,
    "totalReadinessParts": 146,
    "identityState": "FINAL_SOURCE_ACCEPTED_DETACHED_FINAL_PENDING",
    "packageJsonSha256": "adb5e986a2f8062ffae5bee7374ded80157768d62f74af0e412de4a56a1eb557",
    "packageLockSha256": "e795006890fa9230e3bbd9759c3136485d9cc93237deb598f293ee56c4ca04f8",
    "sbomSha256": "88c32b78db48539944662ea3afa2f9fa51af01ffa0dec5c943d6f34f2c605ce4"
  },
  "finalArchive": {
    "filename": "smarter-justice-v1.7.83.zip",
    "version": "1.7.83",
    "identityState": "REPORTED_AFTER_IMMUTABLE_PACKAGING",
    "sha256": null,
    "sizeBytes": null
  },
  "activeMasterPair": {
    "receiptId": "MPCR-2026-07-31-E1-R0-05F4296ED378",
    "transactionId": "MPPT-2026-07-31-SJ8-FP26-304CB87BF174",
    "pairEpoch": 1,
    "pairRevision": 0,
    "receiptSha256": "4dd826cb0f9d89e41528b9732f250899cab45ce89766ae7fdfdb8a44d48d906e",
    "centralMasterSha256": "89f49e1433d05a937a31c2144e42e408a94c4502d8c388ad5f3a6eae7ad5aa68",
    "portalFamilyMasterSha256": "fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f",
    "baselineId": "DRB-2026-07-31-DUR001-DUR043-V2",
    "semanticCapsuleSha256": "3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8"
  },
  "portalAuthority": {
    "record": "INITIAL_PORTAL_AUTHORITY_V1.7.75.json",
    "evidenceBoundary": "OWNER_RECORDED_OR_HANDOFF_RECORDED_NOT_CURRENT_CHAT_PORTAL_INSPECTION",
    "liveConnectionsOpened": false,
    "automaticWritesOpened": false
  },
  "ownerLaunchActionPacket": {
    "record": "OWNER_LAUNCH_ACTION_PACKET_V1.7.75.json",
    "state": "PRIVATE_VALIDATED_NONSECRET_EXECUTION_PACKET",
    "readyNowCount": 4
  },
  "production": {
    "lastVerifiedVersion": "1.6.1",
    "deploymentAuthorized": false,
    "deploymentState": "NOT_DEPLOYED",
    "deployed": false
  },
  "launchState": "NO_GO",
  "deploymentAuthorized": false,
  "publicDisplay": {
    "currentVersion": "1.7.83",
    "sourceAndRollback": "smarter-justice-v1.7.82.zip",
    "finalIdentity": "Reported after immutable packaging; never embedded in the ZIP",
    "promptPack": "V14 exact artifact binding, nonsecret evidence collection, dynamic acceptance evidence bundling, unified live operations, and detached delivery receipt automation accepted locally; external live evidence remains separate.",
    "launch": "NO_GO",
    "deployment": "Not authorized",
    "sourceVersion": "1.7.82"
  },
  "validationState": "FINAL_SOURCE_ACCEPTED_DETACHED_FINAL_PENDING",
  "currentPromptPack": {
    "packId": "SJP-2026-08-02-C15-P37-D11-V13",
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "canonicalCommitProven": false,
    "baselineId": "DRB-2026-08-02-DUR001-DUR086-V13",
    "ruleCount": 86,
    "deploymentFile4State": "PRESERVED_INSIDE_V14"
  },
  "candidateArtifact": {
    "filename": "smarter-justice-v1.7.83-candidate-a.zip",
    "sha256": "97ce078e17ccd96253f04e0300988680683a8dd8f8bf40177ff1d9db12f414cb",
    "sizeBytes": 8886983,
    "entries": 3171,
    "files": 3147,
    "directories": 24,
    "uncompressedBytes": 26377022,
    "compressedBytes": 8405279,
    "payloadInventoryRecords": 3144,
    "payloadInventorySha256": "2d4855f39f5ebe96415bb060aedaab039bc93d88468a23f2e70b48bf641c4dd6",
    "legacyInventoryRecords": 3146,
    "legacyInventorySha256": "cc416c1fdb0eb468bc2212058344fdf4e6d2917ece5db8c98ae3036d5776135f",
    "state": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED"
  },
  "deploymentReadiness": {
    "record": "DEPLOYMENT_READINESS_V1.7.75.json",
    "state": "LOCAL_LAUNCH_DAY_ORCHESTRATION_ACCEPTED_ALL_PRODUCT_PREFLIGHT_PENDING"
  },
  "packId": "SJP-2026-08-02-C15-P37-D11-V13",
  "durableRuleBaseline": "DRB-2026-08-02-DUR001-DUR086-V13",
  "presealArtifact": {
    "candidateSha256": "97ce078e17ccd96253f04e0300988680683a8dd8f8bf40177ff1d9db12f414cb",
    "candidateSizeBytes": 8886983,
    "state": "CANDIDATE_ACCEPTED_FINAL_SOURCE_SEALED"
  },
  "recoveryLineage": {
    "record": "RECOVERY_LINEAGE_RECEIPT_V1.7.75.json",
    "inheritedExactRecoveryBase": "smarter-justice-v1.7.73.zip",
    "unavailableIntermediate": "smarter-justice-v1.7.74.zip",
    "byteExactIntermediateRecoveryClaimed": false,
    "currentExactSource": "smarter-justice-v1.7.82.zip"
  },
  "v12ContinuousImprovement": {
    "packetSha256": "37d90cab818b71613c388bf195b08d129eb569dd183de5358f32dd335975a1d5",
    "innovationPlan": "CONTINUOUS_SELF_IMPROVEMENT_AND_INNOVATION_PLAN_V1.7.83.json",
    "dualImprovementReport": "PRODUCT_AND_PROMPT_DUAL_IMPROVEMENT_REPORT_V1.7.83.json",
    "crossVersionLearning": "CROSS_VERSION_LEARNING_LEDGER_V1.7.83.json",
    "releaseEvidenceCoverageContract": "RELEASE_EVIDENCE_COVERAGE_CONTRACT_V1.7.83.json"
  },
  "workingTreeAcceptance": {
    "record": "WORKING_TREE_ACCEPTANCE_V1.7.83.json",
    "runs": 2,
    "identicalOutput": true,
    "testLogSha256": "65997d8bb250b85b36c1c111f452a3b3caf4f044670fe01e276a21edb5240ef5",
    "state": "FINALIZED_WORKING_TREE_ACCEPTED"
  },
  "candidateAcceptanceRecord": "CANDIDATE_ARTIFACT_ACCEPTANCE_V1.7.83.json",
  "finalSourceAcceptanceRecord": "FINAL_SOURCE_ACCEPTANCE_V1.7.83.json",
  "openAiLaunch": {
    "launchBatchId": "SJP-OPENAI-LIVE-2026-08-03-BATCH-02",
    "overlayCheckpoint": "OPENAI_LAUNCH_OVERLAY_CHECKPOINT_V1.7.83.json",
    "gatewayContract": "AI_GATEWAY_CONTRACT_V1.7.83.json",
    "modelConfiguration": "AI_MODEL_CONFIGURATION_V1.7.83.json",
    "toolPromptRegistry": "AI_TOOL_AND_PROMPT_REGISTRY_V1.7.83.json",
    "capabilityMatrix": "FIVE_PRODUCT_AI_CAPABILITY_MATRIX_V1.7.83.json",
    "vendorPolicy": "OPENAI_ONLY",
    "keyConfigured": false,
    "liveSmokePassed": false,
    "portalCompatibilityReceipts": 0,
    "deploymentAuthorized": false,
    "launchState": "NO_GO"
  },
  "v14": {
    "packetId": "SJP-LMP-UNIVERSAL-ONE-STEP-2026-08-03-V14-ALL-CHAT-MODES",
    "packetSha256": "fce42ce0927748f94189692ef5b3bf8e0fe9f8d12273287f03a68eb7bccdad6f",
    "mode": "MODE_B_EXISTING_CHAT_PACKET_ONLY",
    "artifactBindingReceipt": "ARTIFACT_BINDING_AND_MODE_RECEIPT.json",
    "ownerReceipt": "OWNER_RECEIPT.txt",
    "releasePayloadInventory": "RELEASE_PAYLOAD_INVENTORY_SHA256.txt",
    "unifiedLiveOperations": "V14_UNIFIED_LIVE_OPERATIONS_REGISTER_V1.7.83.json",
    "finalDeliveryIdentity": "REPORTED_AFTER_PACKAGING",
    "liveEvidenceConnector": "V14_LIVE_EVIDENCE_CONNECTOR_CONTRACT_V1.7.83.json",
    "receiptAutomation": "V14_RELEASE_RECEIPT_AUTOMATION_V1.7.83.json",
    "evidenceBatchWorkspace": "V14_EVIDENCE_BATCH_WORKSPACE_CONTRACT_V1.7.83.json",
    "detachedDeliveryReceiptContract": "V14_DETACHED_FINAL_DELIVERY_RECEIPT_CONTRACT_V1.7.83.json",
    "evidenceReadinessPlanner": "V14_EVIDENCE_READINESS_PLANNER_CONTRACT_V1.7.83.json",
    "segmentedAcceptanceManifest": "ACCEPTANCE_SUITE_MANIFEST_V1.7.83.json",
    "segmentedAcceptanceManifestSha256": "568aae7bccd73705db0135d088a786dbcfa5de3fba47fecb61b61f4f1392d737",
    "evidenceCollectionPacket": "V14_EVIDENCE_COLLECTION_PACKET_CONTRACT_V1.7.83.json",
    "acceptanceEvidenceBundle": "V14_ACCEPTANCE_EVIDENCE_BUNDLE_CONTRACT_V1.7.83.json"
  },
  "finalSource": {
    "state": "FINAL_SOURCE_ACCEPTED",
    "runs": 2,
    "commandsPerRun": 145,
    "identicalOutput": true,
    "testLogSha256": "65997d8bb250b85b36c1c111f452a3b3caf4f044670fe01e276a21edb5240ef5",
    "candidateSha256": "97ce078e17ccd96253f04e0300988680683a8dd8f8bf40177ff1d9db12f414cb",
    "candidateSizeBytes": 8886983
  }
};

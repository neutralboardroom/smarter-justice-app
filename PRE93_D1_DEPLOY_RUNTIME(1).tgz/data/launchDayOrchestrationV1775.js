'use strict';
module.exports=Object.freeze(require('../LAUNCH_DAY_ORCHESTRATION_V1.7.75.json'));
